import { protect, jsonError } from './_security.js';

export default async function handler(req, res) {
  const user = await protect(req, res, 'image', 3);
  if (!user) return;
  if (!process.env.OPENAI_API_KEY) return jsonError(res, 503, 'Image generation is not configured.');
  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
  if (!prompt || prompt.length > 2000) return jsonError(res, 400, 'Enter a prompt of up to 2,000 characters.');
  try {
    const upstream = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1', prompt, size: '1024x1024', quality: 'low' })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error('OpenAI image request failed:', upstream.status);
      return jsonError(res, 502, 'Image generation failed.');
    }
    const item = data.data?.[0];
    if (!item?.b64_json) return jsonError(res, 502, 'The image provider returned no image.');
    return res.status(200).json({ image: `data:image/png;base64,${item.b64_json}` });
  } catch (error) {
    console.error('Image generation failed:', error);
    return jsonError(res, 502, 'Image generation is temporarily unavailable.');
  }
}
