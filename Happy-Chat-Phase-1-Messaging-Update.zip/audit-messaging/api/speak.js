import { protect, jsonError } from './_security.js';

export default async function handler(req, res) {
  const user = await protect(req, res, 'speech', 10);
  if (!user) return;
  if (!process.env.OPENAI_API_KEY) return jsonError(res, 503, 'Speech service is not configured.');
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
  if (!text || text.length > 2000) return jsonError(res, 400, 'Enter text of up to 2,000 characters.');
  try {
    const upstream = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts', voice: process.env.OPENAI_TTS_VOICE || 'alloy', input: text, response_format: 'mp3' })
    });
    if (!upstream.ok) {
      console.error('OpenAI speech request failed:', upstream.status);
      return jsonError(res, 502, 'Speech generation failed.');
    }
    const audio = Buffer.from(await upstream.arrayBuffer());
    if (!audio.length || audio.length > 5 * 1024 * 1024) return jsonError(res, 502, 'Speech response was invalid.');
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    return res.status(200).send(audio);
  } catch (error) {
    console.error('Speech generation failed:', error);
    return jsonError(res, 502, 'Speech generation is temporarily unavailable.');
  }
}
