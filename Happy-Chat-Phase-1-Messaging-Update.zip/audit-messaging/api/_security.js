import { createHash } from 'node:crypto';
import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue, Timestamp } from 'firebase-admin/firestore';

const MAX_JSON_BYTES = 1 * 1024 * 1024;
const DAY_MS = 24 * 60 * 60 * 1000;

function send(res, status, payload) {
  res.setHeader('Cache-Control', 'no-store');
  return res.status(status).json(payload);
}

function getAllowedOrigins() {
  const configured = process.env.ALLOWED_ORIGIN;
  if (!configured || configured.includes('*')) return [];
  return configured.split(',').map(value => value.trim()).filter(Boolean).filter(value => {
    try { const parsed = new URL(value); return parsed.origin === value && ['https:', 'http:'].includes(parsed.protocol); }
    catch { return false; }
  });
}

function allowedOrigin(req, res) {
  const origin = req.headers.origin;
  const allowed = getAllowedOrigins();
  if (!origin || !allowed.length || !allowed.includes(origin)) return false;
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Max-Age', '600');
  return true;
}

function initializeAdmin() {
  if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) throw new Error('AUTH_SERVER_NOT_CONFIGURED');
  if (!getApps().length) {
    let service;
    try { service = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON); }
    catch { throw new Error('AUTH_SERVER_NOT_CONFIGURED'); }
    if (!service?.project_id || !service?.client_email || !service?.private_key) throw new Error('AUTH_SERVER_NOT_CONFIGURED');
    if (process.env.FIREBASE_PROJECT_ID && service.project_id !== process.env.FIREBASE_PROJECT_ID) throw new Error('AUTH_SERVER_NOT_CONFIGURED');
    initializeApp({ credential: cert(service), projectId: service.project_id });
  }
}

async function authenticate(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
  if (!token) throw new Error('AUTH_REQUIRED');
  initializeAdmin();
  try { return await getAuth().verifyIdToken(token, true); }
  catch { throw new Error('AUTH_INVALID'); }
}

function bodyBytes(req) {
  const length = Number(req.headers['content-length']);
  if (Number.isFinite(length) && length > MAX_JSON_BYTES) return MAX_JSON_BYTES + 1;
  try { return Buffer.byteLength(JSON.stringify(req.body ?? {}), 'utf8'); }
  catch { return MAX_JSON_BYTES + 1; }
}

async function enforceQuota(uid, feature, dailyLimit, minuteLimit = 5) {
  const db = getFirestore();
  const now = new Date();
  const day = now.toISOString().slice(0, 10);
  const minute = now.toISOString().slice(0, 16).replace(/[-T:]/g, '');
  // Hash the UID for document IDs; keep the original UID only in server-only records.
  const uidKey = createHash('sha256').update(uid).digest('hex');
  const dailyRef = db.collection('_apiUsage').doc(`${uidKey}_${feature}_${day}`);
  const minuteRef = db.collection('_apiUsage').doc(`${uidKey}_${feature}_m_${minute}`);
  await db.runTransaction(async transaction => {
    const [dailySnap, minuteSnap] = await Promise.all([transaction.get(dailyRef), transaction.get(minuteRef)]);
    const dailyCount = dailySnap.exists ? Number(dailySnap.data().count || 0) : 0;
    const minuteCount = minuteSnap.exists ? Number(minuteSnap.data().count || 0) : 0;
    if (dailyCount >= dailyLimit) throw new Error('DAILY_QUOTA_EXCEEDED');
    if (minuteCount >= minuteLimit) throw new Error('RATE_LIMITED');
    transaction.set(dailyRef, { count: dailyCount + 1, feature, day, uid, expiresAt: Timestamp.fromDate(new Date(now.getTime() + 3 * DAY_MS)), updatedAt: FieldValue.serverTimestamp() });
    transaction.set(minuteRef, { count: minuteCount + 1, feature, minute, uid, expiresAt: Timestamp.fromDate(new Date(now.getTime() + DAY_MS)), updatedAt: FieldValue.serverTimestamp() });
  });
}

export async function protect(req, res, feature, dailyLimit) {
  if (!allowedOrigin(req, res)) return send(res, 403, { error: 'Request origin is not allowed.' });
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed.' });
  if (!String(req.headers['content-type'] || '').toLowerCase().includes('application/json')) return send(res, 415, { error: 'Content-Type must be application/json.' });
  if (bodyBytes(req) > MAX_JSON_BYTES) return send(res, 413, { error: 'Request too large.' });
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) return send(res, 400, { error: 'A JSON object is required.' });

  let user;
  try { user = await authenticate(req); }
  catch (error) {
    if (error.message === 'AUTH_SERVER_NOT_CONFIGURED') return send(res, 503, { error: 'Server authentication is not configured.' });
    return send(res, 401, { error: error.message === 'AUTH_REQUIRED' ? 'Please sign in.' : 'Authentication could not be verified.' });
  }
  try { await enforceQuota(user.uid, feature, dailyLimit); }
  catch (error) {
    if (error.message === 'DAILY_QUOTA_EXCEEDED') return send(res, 429, { error: 'Daily usage limit reached. Please try again tomorrow.' });
    if (error.message === 'RATE_LIMITED') return send(res, 429, { error: 'Too many requests. Please wait a minute.' });
    console.error('API quota store failed:', error);
    return send(res, 503, { error: 'Usage protection is temporarily unavailable.' });
  }
  return user;
}

export function jsonError(res, status, message) { return send(res, status, { error: message }); }
