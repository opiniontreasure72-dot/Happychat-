# Happy Chat Social — Video Features

This build supports:

- Video posts in the main feed (up to 50 MB)
- Native play/pause, timeline, volume/mute and full-screen controls
- Video reels (up to 50 MB)
- Video stories (up to 50 MB)
- Video messages in Live Chat
- Video messages in direct messages
- Video cleanup when an owned post is deleted
- Firebase Storage rules for video uploads

## Firebase deployment

Deploy the updated Storage and Firestore rules before testing uploads:

```bash
firebase deploy --only storage,firestore
```

Then deploy the site to Vercel as usual.

The Firebase web configuration remains in `index.html`; this is normal. Protect the backend with Firebase Authentication and the included security rules.
