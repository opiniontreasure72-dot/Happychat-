import http from 'node:http';
import { WebSocketServer } from 'ws';
import { applicationDefault, cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

const port = Number(process.env.PORT || 8080);
const origins = (process.env.ALLOWED_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean);
if (!origins.length) throw new Error('ALLOWED_ORIGIN must contain at least one exact origin.');
const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
const credential = serviceAccount ? cert(JSON.parse(serviceAccount)) : applicationDefault();
if (!getApps().length) initializeApp({ credential, projectId: process.env.FIREBASE_PROJECT_ID });
const auth = getAuth(); const db = getFirestore();
const server = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify({ service: 'happy-chat-realtime', status: 'ok' })); });
const wss = new WebSocketServer({ noServer: true, maxPayload: 4096, perMessageDeflate: false });
const rooms = new Map();
const send = (ws, payload) => { if (ws.readyState === 1) ws.send(JSON.stringify(payload)); };
function leaveAll(ws) { for (const id of ws.rooms || []) { const set = rooms.get(id); set?.delete(ws); if (!set?.size) rooms.delete(id); } ws.rooms?.clear(); }
server.on('upgrade', (req, socket, head) => {
  const origin = req.headers.origin;
  if (!origin || !origins.includes(origin) || req.url !== '/ws') { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
wss.on('connection', ws => {
  ws.uid = null; ws.rooms = new Set(); ws.pendingRooms = new Set(); ws.isAlive = true; ws.rate = { tokens: 40, at: Date.now() }; ws.expiryTimer = null;
  const authDeadline = setTimeout(() => { if (!ws.uid) ws.close(4401, 'authentication timeout'); }, 10_000);
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', async raw => {
    try {
      const now = Date.now();
      ws.rate.tokens = Math.min(40, ws.rate.tokens + (now - ws.rate.at) * (20 / 1000)); ws.rate.at = now;
      if (ws.rate.tokens < 1) { send(ws, { type: 'error', code: 'rate_limited' }); return; }
      ws.rate.tokens -= 1;
      const msg = JSON.parse(raw.toString());
      if (!ws.uid) {
        if (msg.type !== 'authenticate' || typeof msg.token !== 'string' || msg.token.length > 5000) return ws.close(4401, 'authentication required');
        const decoded = await auth.verifyIdToken(msg.token, true); ws.uid = decoded.uid; clearTimeout(authDeadline);
        const remaining = Math.max(0, decoded.exp * 1000 - Date.now() - 5000);
        ws.expiryTimer = setTimeout(() => ws.close(4401, 'token expired; refresh required'), remaining);
        return send(ws, { type: 'authenticated' });
      }
      if (msg.type === 'subscribe' || msg.type === 'unsubscribe') {
        if (typeof msg.conversationId !== 'string' || !/^[A-Za-z0-9_-]{3,160}$/.test(msg.conversationId)) return;
        if (msg.type === 'unsubscribe') { ws.pendingRooms.delete(msg.conversationId); const set = rooms.get(msg.conversationId); set?.delete(ws); if (!set?.size) rooms.delete(msg.conversationId); ws.rooms.delete(msg.conversationId); return; }
        if (ws.rooms.size >= 50 && !ws.rooms.has(msg.conversationId)) return send(ws, { type: 'error', code: 'subscription_limit' });
        ws.pendingRooms.add(msg.conversationId);
        const snap = await db.collection('dm').doc(msg.conversationId).get();
        if (!ws.pendingRooms.has(msg.conversationId)) return; // unsubscribe won the async authorization race
        if (!snap.exists || !Array.isArray(snap.data().participants) || !snap.data().participants.includes(ws.uid)) { ws.pendingRooms.delete(msg.conversationId); return send(ws, { type: 'error', code: 'not_authorized' }); }
        if (!rooms.has(msg.conversationId)) rooms.set(msg.conversationId, new Set());
        rooms.get(msg.conversationId).add(ws); ws.rooms.add(msg.conversationId); ws.pendingRooms.delete(msg.conversationId);
        return send(ws, { type: 'subscribed', conversationId: msg.conversationId });
      }
      if (msg.type === 'message_hint') {
        if (typeof msg.conversationId !== 'string' || typeof msg.messageId !== 'string' || msg.messageId.length > 180 || !ws.rooms.has(msg.conversationId)) return;
        // Hint only: no plaintext or ciphertext is relayed; Firestore remains authoritative.
        const message = await db.collection('dm').doc(msg.conversationId).collection('messages').doc(msg.messageId).get();
        if (!message.exists || message.data().uid !== ws.uid) return;
        for (const peer of rooms.get(msg.conversationId) || []) if (peer !== ws) send(peer, { type: 'sync_hint', conversationId: msg.conversationId, messageId: msg.messageId });
      }
    } catch { send(ws, { type: 'error', code: 'invalid_request' }); }
  });
  ws.on('close', () => { clearTimeout(authDeadline); clearTimeout(ws.expiryTimer); ws.pendingRooms.clear(); leaveAll(ws); }); ws.on('error', () => { clearTimeout(authDeadline); clearTimeout(ws.expiryTimer); ws.pendingRooms.clear(); leaveAll(ws); });
});
const heartbeat = setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; ws.ping(); } }, 25_000);
server.listen(port, '0.0.0.0', () => console.log(`Happy Chat realtime gateway listening on ${port}`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => { clearInterval(heartbeat); for (const ws of wss.clients) ws.close(1001, 'server shutdown'); server.close(() => process.exit(0)); });
