# Happy Chat Realtime Gateway (Phase 1B)

This optional Node service provides authenticated WebSocket **sync hints**. Firestore remains the durable source of truth and existing Firestore listeners remain the fallback. The gateway never receives or relays message plaintext/ciphertext.

## Deploy

Deploy this directory to a host that supports persistent WebSocket connections (not a Vercel serverless function). Set:

- `PORT` (provided by most hosts)
- `ALLOWED_ORIGIN` to exact comma-separated frontend origins, e.g. `https://m.leochat.online`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_SERVICE_ACCOUNT_JSON` as a server-only service-account JSON string, or use Application Default Credentials

Install and start with `npm install && npm start`. Expose `/ws` over `wss://`; `/` is a health endpoint. Keep service-account credentials out of the repository and frontend environment.

## Protocol

Client authenticates with a Firebase ID token, subscribes to a conversation, and publishes a `message_hint` only after the message has been durably written to Firestore. The gateway independently verifies the caller is a conversation participant and verifies the referenced message was authored by that caller. Other subscribed participants receive only `{type:"sync_hint", conversationId, messageId}` and read the encrypted record from Firestore.

This is a single-instance gateway. Multi-instance fan-out requires a shared pub/sub adapter (e.g. Redis) and is deliberately not enabled here. This phase does not claim global low-latency guarantees, message delivery acknowledgements, or production readiness. Firestore listeners remain the recovery path if the gateway is unavailable.
