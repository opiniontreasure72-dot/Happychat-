/** Sandbox contract only. Real gift-card redemption, fiat movement and liquidity are intentionally absent. */
export type GiftCardSimulationRequest = { codeLabel: string; amountMinor: number; currency: 'NGN'|'USD' };
export function simulateGiftCard(request: GiftCardSimulationRequest) {
  if(!request.codeLabel || request.codeLabel.length>40 || !Number.isSafeInteger(request.amountMinor) || request.amountMinor<=0 || request.amountMinor>100_000) throw new Error('Invalid simulation request');
  return { status:'SIMULATED_NOT_REDEEMED', reference:`demo_${crypto.randomUUID()}`, amountMinor:request.amountMinor, currency:request.currency, realFundsMoved:false };
}
