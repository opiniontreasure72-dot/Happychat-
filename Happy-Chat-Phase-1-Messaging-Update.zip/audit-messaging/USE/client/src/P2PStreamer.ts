/** Minimal consent-gated WebRTC negotiation helper; signaling and TURN are supplied by the app. */
export class P2PStreamer {
  private pc?: RTCPeerConnection;
  async start(iceServers: RTCIceServer[], onTrack: (event: RTCTrackEvent)=>void): Promise<RTCPeerConnection> {
    if(!navigator.mediaDevices || !('RTCPeerConnection' in globalThis)) throw new Error('WebRTC is unavailable');
    this.pc = new RTCPeerConnection({iceServers}); this.pc.ontrack=onTrack; return this.pc;
  }
  async addLocalStream(stream:MediaStream):Promise<void>{if(!this.pc)throw new Error('Call start() first'); for(const track of stream.getTracks()) this.pc.addTrack(track,stream);}
  close():void{this.pc?.getSenders().forEach(s=>s.track?.stop());this.pc?.close();this.pc=undefined;}
}
