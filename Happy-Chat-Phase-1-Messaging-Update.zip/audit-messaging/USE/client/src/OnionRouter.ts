/** Deliberately disabled: this is not an onion-routing implementation. */
export class OnionRouter {
  readonly status = 'DISABLED_UNTIL_INDEPENDENT_SECURITY_REVIEW';
  setCircuit(_nodes: string[]): never { throw new Error('Onion routing is not implemented; do not claim anonymity or metadata protection.'); }
  wrapOnion(_payload: Uint8Array): never { throw new Error('Onion routing is disabled.'); }
}
