export type MfeStatus = 'UNLOADED' | 'LOADING' | 'LOADED' | 'MOUNTED' | 'ERROR';
export interface MfeContext { dispatch: (event: string, payload: unknown) => void; subscribe: (event: string, cb: (payload: unknown) => void) => () => void; }
export interface MfeModule { mount(container: HTMLElement, props: Record<string, unknown> & MfeContext): void | Promise<void>; unmount?(): void | Promise<void>; }
export interface MfeConfig { id: string; containerId: string; load: () => Promise<MfeModule>; }

/** Loads trusted, build-time modules. It intentionally does not inject arbitrary URLs/scripts. */
export class MicroFrontendOrchestrator {
  private configs = new Map<string, MfeConfig>();
  private modules = new Map<string, MfeModule>();
  private states = new Map<string, MfeStatus>();
  private events = new Map<string, Set<(payload: unknown) => void>>();
  register(config: MfeConfig): void {
    if (!/^[a-z0-9-]{1,40}$/i.test(config.id) || this.configs.has(config.id)) throw new Error('Invalid or duplicate MFE id');
    this.configs.set(config.id, config); this.states.set(config.id, 'UNLOADED');
  }
  status(id: string): MfeStatus { return this.states.get(id) ?? 'ERROR'; }
  async loadAndMount(id: string, props: Record<string, unknown> = {}): Promise<void> {
    const config = this.configs.get(id); if (!config) throw new Error(`Unknown MFE: ${id}`);
    if (this.states.get(id) === 'MOUNTED') return;
    this.states.set(id, 'LOADING');
    try {
      const module = this.modules.get(id) ?? await config.load();
      if (typeof module.mount !== 'function') throw new Error('MFE must export mount(container, props)');
      this.modules.set(id, module); this.states.set(id, 'LOADED');
      const container = document.getElementById(config.containerId); if (!container) throw new Error('MFE container not found');
      await module.mount(container, { ...props, dispatch: this.dispatch, subscribe: this.subscribe });
      this.states.set(id, 'MOUNTED');
    } catch (error) { this.states.set(id, 'ERROR'); throw error; }
  }
  async unmount(id: string): Promise<void> {
    if (this.states.get(id) !== 'MOUNTED') return;
    await this.modules.get(id)?.unmount?.(); this.states.set(id, 'LOADED');
  }
  dispatch = (event: string, payload: unknown): void => { this.events.get(event)?.forEach(cb => cb(payload)); };
  subscribe = (event: string, cb: (payload: unknown) => void): (() => void) => {
    const listeners = this.events.get(event) ?? new Set(); listeners.add(cb); this.events.set(event, listeners);
    return () => { listeners.delete(cb); if (!listeners.size) this.events.delete(event); };
  };
}
