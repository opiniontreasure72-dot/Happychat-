type SyncMessage = { version: 1; origin: string; key: string; value?: unknown; action: 'set' | 'delete' };
const PREFIX = 'happychat-use:';
/** Small same-origin tab sync layer. Do not use for secrets or authoritative financial state. */
export class StateSyncEngine {
  private db?: IDBDatabase; private channel?: BroadcastChannel; private listeners = new Set<(key: string, value: unknown | undefined) => void>();
  private origin = crypto.randomUUID();
  async open(): Promise<void> {
    if (!('indexedDB' in globalThis)) throw new Error('IndexedDB unavailable');
    this.db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('happychat-use-state', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('state');
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    if ('BroadcastChannel' in globalThis) { this.channel = new BroadcastChannel('happychat-use-state-v1'); this.channel.onmessage = e => this.receive(e.data); }
  }
  async set(key: string, value: unknown): Promise<void> { await this.write(key, value, 'put'); this.broadcast({version:1, origin:this.origin, key, value, action:'set'}); this.notify(key,value); }
  async delete(key: string): Promise<void> { await this.write(key, undefined, 'delete'); this.broadcast({version:1, origin:this.origin, key, action:'delete'}); this.notify(key,undefined); }
  async get<T>(key: string): Promise<T | undefined> { const db=this.requireDb(); return new Promise((resolve,reject)=>{const r=db.transaction('state').objectStore('state').get(PREFIX+key); r.onsuccess=()=>resolve(r.result as T|undefined); r.onerror=()=>reject(r.error);}); }
  subscribe(cb: (key:string,value:unknown|undefined)=>void):()=>void { this.listeners.add(cb); return ()=>this.listeners.delete(cb); }
  close(): void { this.channel?.close(); this.db?.close(); this.listeners.clear(); }
  private requireDb(): IDBDatabase { if(!this.db) throw new Error('Call open() first'); return this.db; }
  private async write(key:string,value:unknown,mode:'put'|'delete'):Promise<void>{const db=this.requireDb(); await new Promise<void>((resolve,reject)=>{const tx=db.transaction('state','readwrite'); const store=tx.objectStore('state'); mode==='put'?store.put(value,PREFIX+key):store.delete(PREFIX+key); tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error); tx.onabort=()=>reject(tx.error);});}
  private broadcast(message:SyncMessage):void {this.channel?.postMessage(message);}
  private receive(raw:unknown):void {if(!raw||typeof raw!=='object')return; const m=raw as SyncMessage; if(m.version!==1||m.origin===this.origin||typeof m.key!=='string'||!['set','delete'].includes(m.action))return; void this.write(m.key,m.value,m.action==='set'?'put':'delete').then(()=>this.notify(m.key,m.action==='set'?m.value:undefined)).catch(()=>{});}
  private notify(key:string,value:unknown|undefined):void {this.listeners.forEach(cb=>cb(key,value));}
}
