export type SandboxEntry = { id: string; accountId: string; deltaMinor: number; currency: 'NGN'|'USD'; createdAt: number; memo: string };
/** UI/demo ledger only. No keys, blockchain RPC, deposits, withdrawals, transfers or real balances. */
export class OpiWalletEngine {
  private entries: SandboxEntry[] = [];
  recordDemoEntry(entry: Omit<SandboxEntry,'id'|'createdAt'>): SandboxEntry {
    if(!entry.accountId || !Number.isSafeInteger(entry.deltaMinor) || Math.abs(entry.deltaMinor)>1_000_000 || !['NGN','USD'].includes(entry.currency)) throw new Error('Invalid demo ledger entry');
    const row={...entry,id:crypto.randomUUID(),createdAt:Date.now()}; this.entries.push(row); return row;
  }
  getDemoEntries(accountId:string): SandboxEntry[] { return this.entries.filter(x=>x.accountId===accountId).map(x=>({...x})); }
  get status():string { return 'SANDBOX_ONLY_NO_REAL_VALUE'; }
}
