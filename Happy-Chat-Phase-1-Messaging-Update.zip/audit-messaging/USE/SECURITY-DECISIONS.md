# USE security decisions and acceptance gates

1. **No remote script injection.** Micro-frontends are trusted build-time imports; no user-controlled URL is executed.
2. **State sync is convenience only.** IndexedDB/BroadcastChannel data is untrusted, same-origin browser state. Never put access tokens, private keys, DM plaintext, or authoritative wallet balances here.
3. **No custom cryptography.** The pasted Shamir and onion snippets are incomplete and contain mixed/truncated code. Do not repair by guesswork. Adopt independently reviewed implementations, versioned test vectors, key lifecycle design, and security review before use.
4. **No real-money features.** Wallet and gift-card code is simulation-only. No Stripe/Plaid, blockchain signing, liquidity routing, cash-out, deposits, or custody is included. Any future real-value feature requires adult/organizational ownership, legal/compliance review, provider approval, and an independent security audit.
5. **No anonymity claims.** Onion routing is disabled. P2P can expose IP addresses and metadata; use a TURN relay and explicit consent, and publish a threat model before enabling.
6. **No browser mining.** Proof-of-engagement mining is excluded.
7. **Integration remains separate.** Do not import USE modules into production Happy Chat routes until typecheck, unit tests, threat model, accessibility review, and performance tests pass.

## Next engineering gates
- Add Vitest tests for orchestrator lifecycle and state synchronization.
- Add Rust unit tests and fuzzing before selecting any crypto crate.
- Define signaling authentication, TURN policy, rate limits, and abuse controls for P2P.
- Define data retention, encryption-at-rest, backup, and cross-tab conflict policy.
- Review dependency licenses, bundle size, and supply-chain posture.
