# Unified Social Engine (USE) — foundation scaffold

This is an isolated, non-production foundation added alongside Happy Chat 4.1.0. Happy Chat remains the main product and Opinion remains its AI assistant.

## Implemented in this scaffold
- Typed micro-frontend registry using trusted in-process loaders (no arbitrary remote script injection).
- IndexedDB + BroadcastChannel state synchronization with namespaced keys and versioned messages.
- Explicitly disabled onion-routing adapter; no anonymity or privacy claim is made.
- Sandbox-only wallet ledger interface; no real assets, custody, gift-card redemption, fiat conversion, payment rails, or off-ramp.
- Consent-gated WebRTC peer connection helper; no WebTorrent auto-seeding or background data sharing.
- Rust/WASM crate boundary with a deliberately unimplemented Shamir adapter.

## Not production-ready
This scaffold does NOT implement multi-chain signing, a state-channel settlement protocol, Shamir secret splitting/reconstruction, onion routing, proof-of-engagement mining, gift-card decryption, Stripe/Plaid transfers, or automated liquidity. Those require independent threat models, audited protocols/libraries, compliance review, and extensive tests. Do not add real funds or secrets.

## Structure
- `client/`: TypeScript modules for the browser.
- `server/`: sandbox-only controller contract.
- `wasm-core/`: Rust/WASM boundary, not a cryptographic implementation.

The client package is intentionally separate from the existing Vite application so dependencies and behavior can be reviewed before integration.
