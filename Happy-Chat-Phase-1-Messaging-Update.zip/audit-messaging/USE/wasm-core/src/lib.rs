use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn engine_status() -> String {
    "USE_WASM_FOUNDATION_ONLY_NO_PRODUCTION_CRYPTO".to_string()
}
