//! Shamir/GF(256) routines are intentionally not implemented here.
//! Use a reviewed, audited cryptographic library and published test vectors.
//! Never treat this placeholder as a gift-card decrypter or key-management system.
