//! Proof-of-engagement mining is intentionally excluded. Browser mining wastes
//! user resources and creates abuse, consent, and battery/performance risks.
