const { onDocumentCreated, onDocumentDeleted, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
initializeApp();
const db = getFirestore();

// Counters are derived from authoritative event documents. Clients must never write count fields.
async function adjustPostCounter(event, field, delta) {
  const data = event.data?.data(); if (!data?.postId || typeof data.postId !== "string") return;
  await db.collection("posts").doc(data.postId).update({ [field]: FieldValue.increment(delta) });
}
async function adjustFollowerCounter(event, delta) {
  const data = event.data?.data(); if (!data?.following || typeof data.following !== "string") return;
  await db.collection("profiles").doc(data.following).update({ followersCount: FieldValue.increment(delta) });
}
exports.onReactionCreated = onDocumentCreated("postReactions/{reactionId}", e => adjustPostCounter(e,"reactionsCount",1));
exports.onReactionDeleted = onDocumentDeleted("postReactions/{reactionId}", e => adjustPostCounter(e,"reactionsCount",-1));
exports.onCommentCreated = onDocumentCreated("postComments/{commentId}", e => adjustPostCounter(e,"commentsCount",1));
exports.onCommentDeleted = onDocumentDeleted("postComments/{commentId}", e => adjustPostCounter(e,"commentsCount",-1));
exports.onFollowAccepted = onDocumentCreated("follows/{followId}", e => e.data?.data()?.status === "accepted" ? adjustFollowerCounter(e,1) : null);
exports.onFollowStatusChanged = onDocumentUpdated("follows/{followId}", async e => {
  const before = e.data.before.data(); const after = e.data.after.data();
  if (before.status === after.status || before.following !== after.following) return;
  if (before.status !== "accepted" && after.status === "accepted") await adjustFollowerCounter({ data: e.data.after }, 1);
  if (before.status === "accepted" && after.status !== "accepted") await adjustFollowerCounter({ data: e.data.before }, -1);
});
exports.onFollowRemoved = onDocumentDeleted("follows/{followId}", e => e.data?.data()?.status === "accepted" ? adjustFollowerCounter(e,-1) : null);
