# Happy Chat — Phase 1 Foundations (cost-minimised)

## Implemented in this package
- Public profile and public post/story/reel document reads are permitted without sign-in only when documents match the existing allow-listed schemas and public visibility. Private profiles and private posts remain restricted.
- Feed/profile/search queries now constrain results to public schemas (`visibility == public`, `isPrivate == false`) rather than issuing broad queries that Firestore rules cannot safely authorize.
- Public post cards show a login prompt for interaction. Existing authenticated-only routes remain guarded.
- Realtime hints now cause a one-shot read from Firestore; hints contain IDs only and Firestore remains the durable source of truth.
- Gateway has a small in-memory token-bucket frame limit, closes connections shortly before Firebase ID-token expiry, and cancels a pending subscription if an unsubscribe arrives while membership is being checked. Client forces an ID-token refresh after gateway close code 4401.
- Added Vitest Web Crypto primitive tests and Firebase Emulator rule tests for anonymous public/private reads, cross-user profile writes, DM sender spoofing, and encrypted DM media reads.
- Added an optional Cloud Functions package for server-derived reaction/comment/follower counters. It is not deployed and no function invocation costs are incurred by this source-only addition.

## Cost controls
- Firestore remains the default realtime transport and durable message store. WebSocket gateway is optional.
- No Redis, MQTT, QUIC, paid search, push provider, or extra always-on service is introduced.
- Cloud Functions are source-only until separately approved and deployed. Deployment may require a billing-enabled Firebase plan and will incur usage-based charges.
- Emulator tests run locally; no production data or infrastructure is modified by this package.

## Local verification
1. Install root dependencies: `npm install`.
2. Run static Node tests: `npm run test:security`.
3. Run Vitest crypto tests: `npm test`.
4. Run Firestore/Storage rules tests: `npm run test:emulators` (downloads/runs Firebase Emulator tooling locally; no production deployment).
5. Run `npm run typecheck`, `npm run lint`, and `npm run build`.
6. Functions dependencies are separate: `cd functions && npm install`. Deploy only after a separate cost review.

## Data migration steps
1. Back up Firestore and Storage before rollout.
2. Inventory legacy posts/profiles. Public posts must use only `uid`, `handle`, `displayName`, optional `text`, optional `imageUrl`/`videoUrl`, `visibility`, `createdAt`, and optional `updatedAt`. Public profiles must use only `uid`, `username`, `displayName`, `photoURL`, `bio`, `isPrivate`, `createdAt`, and `updatedAt`.
3. Convert legacy `imgUrl` to `imageUrl`, legacy `time` to `createdAt`, and explicitly set `visibility: public` only where the owner has authorized public visibility. Never infer public visibility for private/unknown legacy content.
4. Verify migrated documents with emulator tests and sample signed-out browser sessions before publishing rules.
5. Deploy Firestore/Storage rules only after the migration is reviewed. This ZIP does not deploy rules or migrate production data.

## Risks / known limitations
- Legacy documents outside the allow-list will not be readable as public until migrated. The current client has no automatic bulk migration.
- Storage rules still require authentication for the existing post/story/reel object paths because those paths do not encode audience. Making them public would risk exposing private media. Use tokenised public download URLs only for media explicitly designated public, or design a server-checked media manifest before changing Storage rules.
- Public viewing of posts depends on the document schema and any referenced media URL being publicly retrievable.
- Cloud counter triggers expect `postReactions`, `postComments`, and accepted `follows` documents. The current UI does not yet implement all reaction/comment flows, and those collections remain denied to client writes by default rules.
- Counter trigger writes assume the target post/profile exists and is mutable; test in emulator and review idempotency before deployment. Event retries and deletion semantics require further production hardening.
- Current E2EE remains a prototype: private JWK material is stored in IndexedDB, there is no forward secrecy, identity verification, or robust multi-device key management. This phase does not weaken it or claim production-grade E2EE.
- Gateway limits are per connection and in-memory; they do not coordinate across multiple gateway instances. Keep one instance for the low-cost stage.
- No production build, Firebase Emulator run, two-account live test, or deployed-function test has been completed in this environment because dependency installation timed out.

## Phase 1 messaging interaction update (2026-11-09)

Implemented in this update:
- Real-time typing presence via participant-scoped `dm/{conversationId}/typing/{uid}` documents.
- Message replies (stores only the referenced message ID; message text remains encrypted).
- Per-participant emoji reactions with Firestore rules limiting each user to changing their own reaction.
- Author-only message editing; edited text is encrypted again in the browser before the ciphertext is updated.
- Author-only message deletion, with Firestore rules enforcing ownership.
- Read receipts and existing encrypted image/voice-note flows retained.

Not included in this update:
- Group conversations and group E2EE key distribution. The current crypto format wraps each message key for exactly two participants, and the current rules deliberately enforce two-person conversations. Group support must not be enabled by simply relaxing those checks; it needs a multi-recipient key-wrapping design and group membership/key-rotation rules.
- Video/file attachments beyond the existing encrypted image and voice-note types.

After deploying, publish the updated `firestore.rules` with Firebase CLI and verify the changes using the Firestore emulator before production use. Dependency installation could not complete in this environment, so a production build and emulator test run remain outstanding.
