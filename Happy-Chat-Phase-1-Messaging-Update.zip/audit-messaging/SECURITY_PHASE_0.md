# Happy Chat — Phase 0 security hardening

## Required Vercel environment variables

Set these for the Production environment (and separately for Preview only if needed):

- `ALLOWED_ORIGIN`: exact origin, for example `https://m.leochat.online`. Multiple origins may be comma-separated. Wildcards are rejected.
- `FIREBASE_SERVICE_ACCOUNT_JSON`: complete Firebase service-account JSON for project `opinion-df052`. Keep this server-side only.
- `FIREBASE_PROJECT_ID`: must match the service account project ID (`opinion-df052`).
- `OPENAI_API_KEY`: server-side OpenAI API key.
- Optional model overrides: `OPENAI_MODEL`, `OPENAI_IMAGE_MODEL`, `OPENAI_TTS_MODEL`, `OPENAI_TTS_VOICE`.

Do not prefix secrets with `VITE_`. Never commit a service-account file or private key.

## API controls added

All three AI endpoints now require a Firebase ID token verified by Firebase Admin with revocation checking. Requests must originate from an explicitly configured origin. Each endpoint has a transactional Firestore usage counter, a per-minute limit, a daily limit, and a 1 MiB JSON-body cap. Daily limits: chat 30, image generation 3, speech 10 per Firebase UID. Quota documents are server-only.

The quotas are enforced through Firestore transactions, so configure Firestore and a valid service account before deploying. If authentication or origin configuration is missing, requests fail closed.

## Important deployment warning

The Firestore and Storage rules have been tightened. Existing legacy clients may still write old field names (including email-based `user` fields) and may stop working until the client is migrated to the allow-listed schema. This is intentional fail-closed behavior; do not loosen the rules just to make an old client work. Test with the Firebase Emulator Suite and migrate the UI before production rollout.

DM media reads are restricted to the uploading UID until a server-authorized participant delivery mechanism is implemented. This can temporarily prevent recipients from loading DM attachments. Do not make the DM media bucket public.

## Verification still required before production

The Opinion React page now sends the API contract expected by `/api/chat` (`message` and `history`), rather than the unsupported `messages` property. A Node contract test suite is included at `tests/security-config.test.js`; run it with `npm run test:security`. These tests are not a substitute for Firebase Emulator rule tests or a live authenticated API smoke test.

1. Set the Vercel environment variables and redeploy.
2. Run Firebase Emulator rule tests for anonymous access, cross-user profile edits, post tampering, forged notifications, DM participant spoofing, and unauthorized Storage reads.
3. Verify API requests without a token return 401; wrong/missing origin returns 403; rate and daily quota limits return 429. Use a test Firebase project and test account.
4. Confirm `npm ci`, `npm run lint`, `npm run typecheck`, and `npm run build` on a clean environment.
5. Migrate legacy data before publishing these Firestore rules. The legacy profile writer stores an email address in `profiles`, and the legacy post/chat/story/reel writers use older field names. The new allow-list intentionally rejects those writes. The SPA must be migrated to the allow-listed public/private profile model and post schema first; otherwise publishing these rules can break signup and legacy content. Public posts/profiles are only readable when their documents match the new schema and explicitly declare public visibility.

Security headers are configured in `vercel.json`. CSP is report-only initially because the existing app still contains legacy inline scripts and external Firebase resources. Convert it to enforcing CSP only after collecting and reviewing violations.

## Firestore TTL cleanup

Enable Firestore Time-to-Live for the `_apiUsage` collection group on the `expiresAt` field. The counters include expiry timestamps; without the TTL policy, old counter documents remain stored (quota enforcement still works).
