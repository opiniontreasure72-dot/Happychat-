import { useEffect, useState, lazy, Suspense } from "react";
import {
  Routes, Route, NavLink, Link, Navigate, useLocation, useNavigate,
  useParams, useSearchParams
} from "react-router-dom";
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, signOut, User } from "firebase/auth";
import { collection, getDocs, limit, orderBy, query, where, doc, getDoc, runTransaction, serverTimestamp } from "firebase/firestore";
import { auth, db } from "./firebase";

const Opinion = lazy(() => import("./pages/Opinion"));
const Messages = lazy(() => import("./pages/Messages"));
const ChatRoom = lazy(() => import("./pages/ChatRoom"));

type Profile = {
  uid: string; displayName?: string; username?: string; bio?: string; photoURL?: string; isPrivate?: boolean;
};

function usePageMeta(title: string, description: string) {
  useEffect(() => {
    document.title = `${title} — Happy Chat`;
    const setMeta = (name: string, content: string) => {
      let el = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
      if (!el) { el = document.createElement("meta"); el.name = name; document.head.appendChild(el); }
      el.content = content;
    };
    setMeta("description", description);
    const canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    const link = canonical ?? document.createElement("link");
    link.rel = "canonical"; link.href = window.location.href.split("?")[0];
    if (!canonical) document.head.appendChild(link);
  }, [title, description]);
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => onAuthStateChanged(auth, u => { setUser(u); setLoading(false); }), []);
  if (loading) return <Loading />;
  return <AppShell user={user}><Routes>
    <Route path="/" element={<Feed user={user} />} />
    <Route path="/post/:id" element={<Post />} />
    <Route path="/u/:handle" element={<ProfilePage user={user} />} />
    <Route path="/chat" element={<Guard user={user}><Suspense fallback={<Loading />}><ChatRoom /></Suspense></Guard>} />
    <Route path="/messages" element={<Guard user={user}><Messages /></Guard>} />
    <Route path="/messages/:conversationId" element={<Guard user={user}><Messages /></Guard>} />
    <Route path="/reels" element={<Reels />} />
    <Route path="/stories/:uid" element={<Stories />} />
    <Route path="/search" element={<Search />} />
    <Route path="/notifications" element={<Guard user={user}><Notifications /></Guard>} />
    <Route path="/settings" element={<Guard user={user}><Settings /></Guard>} />
    <Route path="/opinion" element={<Guard user={user}><Suspense fallback={<Loading />}><Opinion /></Suspense></Guard>} />
    <Route path="/login" element={user ? <Navigate to="/" replace /> : <Auth mode="login" />} />
    <Route path="/signup" element={user ? <Navigate to="/" replace /> : <Auth mode="signup" />} />
    <Route path="/reset-password" element={<ResetPassword />} />
    <Route path="/legal/terms" element={<Legal title="Terms of Service" />} />
    <Route path="/legal/privacy" element={<Legal title="Privacy Policy" />} />
    <Route path="*" element={<NotFound />} />
  </Routes></AppShell>;
}

function AppShell({ user, children }: { user: User | null; children: React.ReactNode }) {
  const location = useLocation();
  usePageMeta(routeTitle(location.pathname), routeDescription(location.pathname));
  return <div className="app">
    <header className="topbar">
      <Link className="brand" to="/"><img src="/assets/happy-chat-logo.png" alt="Happy Chat" /><span>Happy Chat</span></Link>
      <nav className="desktop-nav">
        <NavLink to="/">Home</NavLink>
        <NavLink to="/reels">Reels</NavLink>
        <NavLink to="/search">Search</NavLink>
        {user && <NavLink to="/chat">Live Chat</NavLink>}
        {user && <NavLink to="/messages">Messages</NavLink>}
        {user && <NavLink to="/opinion">Opinion</NavLink>}
      </nav>
      <div className="account-actions">
        {user ? <><Link to={`/u/${user.displayName || user.uid}`}>Profile</Link><button className="ghost" onClick={() => signOut(auth)}>Sign out</button></> :
          <><Link className="button secondary" to="/login">Log in</Link><Link className="button" to="/signup">Sign up</Link></>}
      </div>
    </header>
    <main>{children}</main>
    <footer><Link to="/legal/terms">Terms</Link><Link to="/legal/privacy">Privacy</Link><span>Happy Chat · Opinion AI</span></footer>
  </div>;
}

function Guard({ user, children }: { user: User | null; children: React.ReactNode }) {
  const location = useLocation();
  if (!user) return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  return <>{children}</>;
}

function Loading() { return <div className="center-state"><div className="spinner" /><p>Loading Happy Chat…</p></div>; }

async function loadPosts() {
  try {
    const snap = await getDocs(query(collection(db, "posts"), where("visibility", "==", "public"), orderBy("createdAt", "desc"), limit(30)));
    return snap.docs.map(d => ({ id: d.id, ...d.data() as any }));
  } catch {
    try {
      const snap = await getDocs(query(collection(db, "posts"), where("visibility", "==", "public"), limit(30)));
      return snap.docs.map(d => ({ id: d.id, ...d.data() as any }));
    } catch { return []; }
  }
}

function Feed({ user }: { user: User | null }) {
  usePageMeta("Home", "Public Happy Chat feed.");
  const [posts, setPosts] = useState<any[]>([]);
  useEffect(() => { loadPosts().then(setPosts); }, []);
  return <section className="page">
    <div className="hero"><div><p className="eyebrow">WELCOME TO HAPPY CHAT</p><h1>Connect, share and discover.</h1><p>Public content can be viewed without an account. Sign in when you want to interact.</p></div>{!user && <Link className="button" to="/signup">Create account</Link>}</div>
    <div className="section-heading"><h2>Home feed</h2><Link to="/search">Explore</Link></div>
    {posts.length ? <div className="feed">{posts.map(p => <PostCard key={p.id} post={p} />)}</div> :
      <Empty title="Your feed is ready" text="Public posts will appear here when they are available." />}
  </section>;
}

function PostCard({ post }: { post: any }) {
  const author = post.displayName || post.userName || post.author?.displayName || "Happy Chat user";
  const handle = post.username || post.handle || "";
  return <article className="card post-card">
    <div className="post-author"><div className="avatar">{String(author).slice(0,1).toUpperCase()}</div><div><strong>{author}</strong>{handle && <div className="muted">@{handle}</div>}</div></div>
    {post.text && <p className="post-text">{post.text}</p>}
    {(post.imageUrl || post.imgUrl) && <img className="post-media" src={post.imageUrl || post.imgUrl} alt="" loading="lazy" />}
    {post.videoUrl && <video className="post-media" src={post.videoUrl} controls playsInline preload="metadata" />}
    <div className="post-link"><Link to={`/post/${post.id}`}>Open post</Link><Link className="button secondary" to={`/login?redirect=${encodeURIComponent(`/post/${post.id}`)}`}>Log in to react or comment</Link></div>
  </article>;
}

function Post() {
  const { id } = useParams(); const [post, setPost] = useState<any | null>(null);
  usePageMeta("Post", "View a public Happy Chat post.");
  useEffect(() => { if (id) getDoc(doc(db, "posts", id)).then(s => setPost(s.exists() ? {id:s.id,...s.data()} : null)).catch(()=>setPost(null)); }, [id]);
  if (!post) return <Empty title="Post not found" text="This post may have been deleted or is not public." />;
  return <section className="page narrow"><div className="section-heading"><Link to="/">← Home</Link><h1>Post</h1></div><PostCard post={post}/></section>;
}

function ProfilePage({ user }: { user: User | null }) {
  const { handle } = useParams(); const [profile,setProfile]=useState<Profile|null>(null); const [posts,setPosts]=useState<any[]>([]);
  usePageMeta(`@${handle || "profile"}`, "Public Happy Chat profile.");
  useEffect(() => {
    if (!handle) return;
    getDocs(query(collection(db,"profiles"),where("username","==",handle.toLowerCase()),where("isPrivate","==",false),limit(1))).then(async snap=>{
      if (!snap.empty) {
        const p={uid:snap.docs[0].id,...snap.docs[0].data()} as Profile; setProfile(p);
        const ps=await getDocs(query(collection(db,"posts"),where("uid","==",p.uid),where("visibility","==","public"),limit(20))); setPosts(ps.docs.map(d=>({id:d.id,...d.data()})));
      } else setProfile(null);
    }).catch(()=>setProfile(null));
  },[handle]);
  if (!profile) return <Empty title="Profile not found" text="The public profile could not be found." />;
  if (profile.isPrivate && profile.uid !== user?.uid) return <section className="page narrow"><div className="profile-hero"><div className="avatar xl">{(profile.displayName||"U").slice(0,1)}</div><h1>{profile.displayName || "User"}</h1><p>@{profile.username}</p><div className="private-box">This account is private.</div></div></section>;
  return <section className="page narrow"><div className="profile-hero"><div className="avatar xl">{(profile.displayName||"U").slice(0,1)}</div><h1>{profile.displayName || "User"}</h1><p>@{profile.username}</p>{profile.bio&&<p>{profile.bio}</p>}</div><h2>Posts</h2>{posts.length?posts.map(p=><PostCard key={p.id} post={p}/>):<Empty title="No public posts" text="There are no public posts to show."/>}</section>;
}

function Reels(){ usePageMeta("Reels","Discover public short videos."); return <section className="page"><div className="section-heading"><h1>Reels</h1><span className="muted">Public videos</span></div><Empty title="Reels are being connected" text="The SPA route is live. Existing Reel data can be migrated into this route without changing the URL." /></section>; }
function Stories(){ const {uid}=useParams(); usePageMeta("Stories","View permitted public stories."); return <section className="page narrow"><h1>Stories</h1><p className="muted">Stories for {uid}</p><Empty title="Story viewer ready" text="Server-side story expiry and privacy rules remain part of the security migration." /></section>; }
function Notifications(){ usePageMeta("Notifications","Your Happy Chat notifications."); return <section className="page narrow"><h1>Notifications</h1><Empty title="No notifications yet" text="Notifications will appear here when server-authoritative fan-out is enabled." /></section>; }
function Settings(){ usePageMeta("Settings","Manage your Happy Chat account."); return <section className="page narrow"><h1>Settings</h1><div className="card settings-list"><Link to="/legal/privacy">Privacy</Link><Link to="/legal/terms">Terms</Link><button onClick={()=>signOut(auth)}>Sign out</button></div></section>; }

function Search(){
  const [params,setParams]=useSearchParams(); const term=params.get("q")||""; const [q,setQ]=useState(term); const [profiles,setProfiles]=useState<any[]>([]);
  usePageMeta("Search","Search public Happy Chat profiles.");
  const run=async(e?:React.FormEvent)=>{e?.preventDefault();setParams(q?{q}:{});if(!q.trim()){setProfiles([]);return;}try{const s=await getDocs(query(collection(db,"profiles"),where("isPrivate","==",false),where("username",">=",q.toLowerCase()),where("username","<=",q.toLowerCase()+"\uf8ff"),limit(20)));setProfiles(s.docs.map(d=>({uid:d.id,...d.data()})));}catch{setProfiles([])}};
  useEffect(()=>{if(term)run()},[term]);
  return <section className="page narrow"><h1>Search</h1><form className="search" onSubmit={run}><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search public users" aria-label="Search public users"/><button className="button">Search</button></form><div className="results">{profiles.map(p=><Link className="result" key={p.uid} to={`/u/${p.username}`}><div className="avatar">{(p.displayName||"U").slice(0,1)}</div><div><strong>{p.displayName||"User"}</strong><span>@{p.username}</span></div></Link>)}</div></section>;
}

function Auth({mode}:{mode:"login"|"signup"}) {
  const [params]=useSearchParams(); const nav=useNavigate(); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [name,setName]=useState(""); const [username,setUsername]=useState(""); const [error,setError]=useState("");
  usePageMeta(mode==="login"?"Log in":"Sign up","Access your Happy Chat account.");
  const submit=async(e:React.FormEvent)=>{e.preventDefault();setError("");try{if(mode==="login") await signInWithEmailAndPassword(auth,email,password);else {const handle=username.trim().toLowerCase();if(!/^[a-z0-9_]{3,20}$/.test(handle)) throw new Error("Username must be 3–20 characters and use only letters, numbers or underscores.");const cred=await createUserWithEmailAndPassword(auth,email,password);const displayName=name.trim();await cred.user.updateProfile({displayName});await runTransaction(db,async tx=>{const usernameRef=doc(db,"usernames",handle);const existing=await tx.get(usernameRef);if(existing.exists()) throw new Error("That username is already taken. Choose another one.");tx.set(usernameRef,{uid:cred.user.uid,createdAt:serverTimestamp()});tx.set(doc(db,"profiles",cred.user.uid),{uid:cred.user.uid,username:handle,displayName,photoURL:"",bio:"",isPrivate:false,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});});}nav(params.get("redirect")||"/");}catch(err:any){setError(err?.message||"Authentication failed.");}};
  return <section className="auth-page"><form className="auth-card" onSubmit={submit}><img src="/assets/happy-chat-logo.png" alt="" /><h1>{mode==="login"?"Welcome back":"Join Happy Chat"}</h1>{mode==="signup"&&<><input value={name} onChange={e=>setName(e.target.value)} placeholder="Display name" maxLength={80} required/><input value={username} onChange={e=>setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g,""))} placeholder="Username (e.g. alex_123)" minLength={3} maxLength={20} autoCapitalize="none" required/></>}<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" required/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" minLength={8} required/>{error&&<div className="error">{error}</div>}<button className="button">{mode==="login"?"Log in":"Create account"}</button>{mode==="login"&&<Link to="/reset-password">Forgot password?</Link>}<p className="muted">{mode==="login"?<>New here? <Link to="/signup">Create an account</Link></>:<>Already registered? <Link to="/login">Log in</Link></>}</p></form></section>;
}

function ResetPassword(){const [email,setEmail]=useState("");const [sent,setSent]=useState(false);const [error,setError]=useState("");usePageMeta("Reset password","Reset your Happy Chat password.");return <section className="auth-page"><form className="auth-card" onSubmit={async e=>{e.preventDefault();try{await sendPasswordResetEmail(auth,email);setSent(true)}catch(err:any){setError(err.message)}}}><h1>Reset password</h1>{sent?<p>Check your email for the reset link.</p>:<><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" required/><button className="button">Send reset link</button>{error&&<div className="error">{error}</div>}</>}<Link to="/login">Back to login</Link></form></section>}

function Legal({title}:{title:string}){usePageMeta(title,title);return <section className="page narrow"><h1>{title}</h1><div className="card"><p>This page is a draft for Happy Chat. Legal text must be reviewed and approved before being presented as a final legal policy.</p></div></section>}
function NotFound(){usePageMeta("Page not found","The Happy Chat page could not be found.");return <Empty title="404 — Page not found" text="The page does not exist."/>}
function Empty({title,text}:{title:string;text:string}){return <div className="empty card"><h2>{title}</h2><p>{text}</p><Link className="button" to="/">Go home</Link></div>}
function routeTitle(p:string){if(p==="/")return"Home";if(p.startsWith("/u/"))return"Profile";if(p.startsWith("/post/"))return"Post";return p.split("/")[1]?.replace(/-/g," ")||"Happy Chat"}
function routeDescription(p:string){if(p==="/")return"Public Happy Chat feed.";return"Happy Chat social platform with Opinion AI."}
