// Legacy module manifest. The active application is the Vite/React SPA.
// Feature flags are intentionally descriptive until each service is migrated.
window.HappyChatModules = {
  architecture: "vite-react-spa",
  version: "4.1.0",
  legacyFeaturesPendingMigration: ["reels", "stories", "encrypted-messages", "notifications"]
};
