import { useState } from "react";
import { auth } from "../firebase";

type ChatMessage = { role: "user" | "assistant"; content: string };

export default function Opinion() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const send = async () => {
    const text = input.trim();
    const user = auth.currentUser;
    if (!text || busy) return;
    if (!user) { setError("Please sign in to use Opinion."); return; }
    setInput(""); setError(""); setBusy(true);
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    try {
      const token = await user.getIdToken();
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: text, history: messages.slice(-10) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data?.error || "Opinion could not respond.");
      setMessages(current => [...current, { role: "assistant", content: String(data?.reply || "Opinion returned an empty response.") }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Opinion is temporarily unavailable.");
    } finally { setBusy(false); }
  };

  return <section className="page narrow"><div className="section-heading"><h1>Opinion</h1><span className="muted">AI assistant</span></div><div className="card opinion"><div className="opinion-history" aria-live="polite">{messages.length ? messages.map((m, i) => <div className={`bubble ${m.role}`} key={i}>{m.content}</div>) : <p className="muted">Ask Opinion for help with writing, ideas, learning or planning.</p>}{busy && <p className="muted">Opinion is thinking…</p>}</div>{error && <p className="error" role="alert">{error}</p>}<div className="opinion-input"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Message Opinion…" rows={2} disabled={busy}/><button className="button" onClick={() => void send()} disabled={busy || !input.trim()}>{busy ? "Sending…" : "Send"}</button></div></div></section>;
}
