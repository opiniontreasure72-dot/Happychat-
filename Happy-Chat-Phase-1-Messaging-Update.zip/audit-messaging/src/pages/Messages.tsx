import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { auth, db, storage } from "../firebase";
import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs, limit, onSnapshot, orderBy,
  query, serverTimestamp, setDoc, updateDoc, where
} from "firebase/firestore";
import { getBytes, ref, uploadBytes } from "firebase/storage";
import { decryptDirectMessage, decryptDmAttachment, encryptDirectMessage, encryptDmAttachment, ensureDmIdentity } from "../services/dm-crypto";
import { RealtimeTransport } from "../services/realtime-transport";

type Conversation = { id: string; participants: string[]; lastMessagePreview?: string; lastSenderUid?: string; updatedAt?: any };
type Attachment = { path: string; iv: string; wrappedKeys: Record<string, string>; contentType: string; fileName: string; size: number; mediaKind: "image" | "audio" };
type Message = { id: string; uid: string; ciphertext: string; iv: string; wrappedKeys: Record<string, string>; createdAt?: any; readAt?: any; editedAt?: any; replyToId?: string; reactions?: Record<string, string>; attachment?: Attachment };
type Person = { uid: string; username?: string; displayName?: string; photoURL?: string };
function conversationId(a: string, b: string) { return [a, b].sort().join("__"); }
function timeLabel(value: any) { const date = value?.toDate?.() || (value instanceof Date ? value : null); return date ? date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""; }
function isOnline(value: any) { const date = value?.toDate?.(); return !!date && Date.now() - date.getTime() < 75_000; }

export default function Messages() {
  const user = auth.currentUser;
  const { conversationId: routeId } = useParams();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [people, setPeople] = useState<Record<string, Person>>({});
  const [activePerson, setActivePerson] = useState<Person | null>(null);
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const typingTimer = useRef<number | undefined>(undefined);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<Person[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("Messages are encrypted on this device.");
  const [decrypted, setDecrypted] = useState<Record<string, string>>({});
  const [presence, setPresence] = useState<Record<string, any>>({});
  const [mediaUrls, setMediaUrls] = useState<Record<string, string>>({});
  const [recording, setRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const fileInput = useRef<HTMLInputElement>(null);
  const recorder = useRef<MediaRecorder | null>(null);
  const recordingChunks = useRef<Blob[]>([]);
  const recordingTimer = useRef<number | undefined>(undefined);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaUrlsRef = useRef<string[]>([]);
  const realtimeRef = useRef<RealtimeTransport | null>(null);

  useEffect(() => {
    if (!user) return;
    const url = (import.meta as any).env?.VITE_REALTIME_WS_URL as string | undefined;
    if (!url) return; // Firestore realtime listeners remain the default fallback.
    const transport = new RealtimeTransport(url, (forceRefresh) => user.getIdToken(!!forceRefresh));
    realtimeRef.current = transport;
    transport.connect();
    return () => { transport.close(); if (realtimeRef.current === transport) realtimeRef.current = null; };
  }, [user?.uid]);

  useEffect(() => {
    if (!routeId || !realtimeRef.current) return;
    return realtimeRef.current.subscribe(routeId);
  }, [routeId, !!user]);

  useEffect(() => {
    const transport = realtimeRef.current;
    if (!transport || !routeId || !user) return;
    return transport.onHint(hint => {
      if (hint.conversationId !== routeId) return;
      // Hints never carry message content. Re-read the durable, participant-guarded Firestore source.
      void getDocs(query(collection(db, "dm", routeId, "messages"), orderBy("createdAt", "desc"), limit(100)))
        .then(snapshot => setMessages(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Message)).reverse()))
        .catch(() => { /* The existing onSnapshot listener remains the fallback. */ });
    });
  }, [routeId, user?.uid]);

  useEffect(() => {
    if (!user) return;
    ensureDmIdentity(user.uid).catch(e => setError(e?.message || "Could not prepare encrypted messaging."));
    const presenceRef = doc(db, "presence", user.uid);
    const beat = () => setDoc(presenceRef, { uid: user.uid, active: true, updatedAt: serverTimestamp() }, { merge: true }).catch(() => {});
    beat();
    const interval = window.setInterval(beat, 30_000);
    const onVisible = () => { if (document.visibilityState === "visible") beat(); };
    document.addEventListener("visibilitychange", onVisible);
    const q = query(collection(db, "dm"), where("participants", "array-contains", user.uid));
    const stop = onSnapshot(q, snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() } as Conversation));
      rows.sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
      setConversations(rows);
    }, e => setError(e.message || "Could not load conversations."));
    return () => { clearInterval(interval); document.removeEventListener("visibilitychange", onVisible); stop(); setDoc(presenceRef, { uid: user.uid, active: false, updatedAt: serverTimestamp() }, { merge: true }).catch(() => {}); };
  }, [user?.uid]);

  useEffect(() => {
    if (!user || !routeId) { setMessages([]); setActivePerson(null); return; }
    let stop: (() => void) | undefined; let alive = true;
    (async () => {
      try {
        const conversation = await getDoc(doc(db, "dm", routeId));
        if (!conversation.exists()) throw new Error("Conversation not found.");
        const data = conversation.data() as Conversation;
        if (!data.participants?.includes(user.uid) || data.participants.length !== 2) throw new Error("This screen currently supports secure one-to-one conversations only.");
        const otherUid = data.participants.find(id => id !== user.uid)!;
        let p: Person = { uid: otherUid, displayName: "Happy Chat user" };
        try { const profile = await getDoc(doc(db, "profiles", otherUid)); if (profile.exists()) p = { uid: otherUid, ...profile.data() } as Person; }
        catch { p = { uid: otherUid, displayName: "Private account" }; }
        if (alive) { setActivePerson(p); setPeople(old => ({ ...old, [otherUid]: p })); }
        stop = onSnapshot(query(collection(db, "dm", routeId, "messages"), orderBy("createdAt", "desc"), limit(100)), snap => {
          const rows = snap.docs.map(d => ({ id: d.id, ...d.data() } as Message)).reverse();
          setMessages(rows);
          rows.filter(m => m.uid !== user.uid && !m.readAt).forEach(m => updateDoc(doc(db, "dm", routeId, "messages", m.id), { readAt: serverTimestamp() }).catch(() => {}));
        }, e => setError(e.message || "Could not load messages."));
      } catch (e: any) { if (alive) setError(e?.message || "Could not open conversation."); }
    })();
    return () => { alive = false; stop?.(); };
  }, [user?.uid, routeId]);

  useEffect(() => {
    if (!user || !conversations.length) return;
    let cancelled = false;
    (async () => {
      const missing = [...new Set(conversations.map(c => c.participants.find(uid => uid !== user.uid)).filter((uid): uid is string => !!uid && !people[uid]))].slice(0, 30);
      const loaded: Record<string, Person> = {};
      await Promise.all(missing.map(async uid => { try { const profile = await getDoc(doc(db, "profiles", uid)); loaded[uid] = profile.exists() ? ({ uid, ...profile.data() } as Person) : { uid, displayName: "Happy Chat user" }; } catch { loaded[uid] = { uid, displayName: "Private account" }; } }));
      if (!cancelled && Object.keys(loaded).length) setPeople(old => ({ ...old, ...loaded }));
    })();
    return () => { cancelled = true; };
  }, [user?.uid, conversations]);

  useEffect(() => {
    if (!activePerson) return;
    return onSnapshot(doc(db, "presence", activePerson.uid), snap => setPresence(old => ({ ...old, [activePerson.uid]: snap.exists() ? snap.data() : null })));
  }, [activePerson?.uid]);

  useEffect(() => {
    if (!user || !routeId) { setTypingUsers([]); return; }
    return onSnapshot(collection(db, "dm", routeId, "typing"), snap => {
      setTypingUsers(snap.docs.filter(d => d.id !== user.uid && Date.now() - (d.data().updatedAt?.toMillis?.() || 0) < 7000).map(d => d.id));
    });
  }, [user?.uid, routeId]);

  const publishTyping = () => {
    if (!user || !routeId) return;
    void setDoc(doc(db, "dm", routeId, "typing", user.uid), { uid: user.uid, updatedAt: serverTimestamp() }).catch(() => {});
    if (typingTimer.current) clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(() => { void deleteDoc(doc(db, "dm", routeId, "typing", user.uid)).catch(() => {}); }, 5000);
  };

  useEffect(() => {
    if (!user || !routeId || !messages.length) return;
    let cancelled = false;
    (async () => {
      const next: Record<string, string> = {};
      for (const message of messages) {
        try { next[message.id] = await decryptDirectMessage(user.uid, message); }
        catch { next[message.id] = message.attachment ? "" : "Unable to decrypt on this device"; }
        if (cancelled) return;
      }
      setDecrypted(next);
    })();
    return () => { cancelled = true; };
  }, [user?.uid, routeId, messages]);

  useEffect(() => {
    if (!user || !routeId) return;
    let cancelled = false;
    (async () => {
      for (const message of messages) {
        if (!message.attachment || mediaUrls[message.id]) continue;
        try {
          const encrypted = await getBytes(ref(storage, message.attachment.path));
          const cipherBuffer = new Uint8Array(encrypted).buffer;
          const blob = await decryptDmAttachment(user.uid, message.attachment.iv, message.attachment.wrappedKeys, cipherBuffer);
          if (cancelled) return;
          const objectUrl = URL.createObjectURL(new Blob([blob], { type: message.attachment!.contentType }));
          mediaUrlsRef.current.push(objectUrl);
          setMediaUrls(old => ({ ...old, [message.id]: objectUrl }));
        } catch { if (!cancelled) setNotice("An attachment could not be opened on this device."); }
      }
    })();
    return () => { cancelled = true; };
  }, [user?.uid, routeId, messages]);

  useEffect(() => () => { mediaUrlsRef.current.forEach(URL.revokeObjectURL); }, []);

  const searchUsers = async (event: FormEvent) => {
    event.preventDefault(); setError(""); const term = search.trim().replace(/^@/, "").toLowerCase();
    if (!term || !user) { setResults([]); return; }
    try { const snap = await getDocs(query(collection(db, "profiles"), where("isPrivate", "==", false), where("username", ">=", term), where("username", "<=", term + "\uf8ff"), limit(12))); setResults(snap.docs.filter(d => d.id !== user.uid && d.data().isPrivate !== true).map(d => ({ uid: d.id, ...d.data() } as Person))); }
    catch (e: any) { setError(e?.message || "Search failed. Check that your profile search index is available."); }
  };
  const startConversation = async (person: Person) => {
    if (!user) return; setBusy(true); setError("");
    try { await ensureDmIdentity(user.uid); const id = conversationId(user.uid, person.uid); const refDoc = doc(db, "dm", id); const existing = await getDoc(refDoc); if (!existing.exists()) await setDoc(refDoc, { participants: [user.uid, person.uid].sort(), createdBy: user.uid, createdAt: serverTimestamp(), updatedAt: serverTimestamp(), lastMessagePreview: "" }); setPeople(old => ({ ...old, [person.uid]: person })); setActivePerson(person); setResults([]); setSearch(""); navigate(`/messages/${id}`); }
    catch (e: any) { setError(e?.message || "Could not start conversation."); } finally { setBusy(false); }
  };

  const sendPayload = async (text: string, file?: Blob) => {
    if (!user || !routeId || busy) return;
    setBusy(true); setError("");
    try {
      const conversationRef = doc(db, "dm", routeId); const conversation = await getDoc(conversationRef);
      if (!conversation.exists() || !conversation.data().participants?.includes(user.uid)) throw new Error("Conversation access could not be verified.");
      const participants = conversation.data().participants as string[]; const recipient = participants.find(uid => uid !== user.uid)!;
      const encrypted = await encryptDirectMessage(user.uid, recipient, text);
      let attachment: Attachment | undefined;
      if (file) {
        if (file.size > 8 * 1024 * 1024) throw new Error("Attachments must be 8 MB or smaller.");
        const media = await encryptDmAttachment(user.uid, recipient, file);
        const path = `dmMedia/${routeId}/${user.uid}/${crypto.randomUUID()}.bin`;
        await uploadBytes(ref(storage, path), media.encrypted, { contentType: "application/octet-stream", customMetadata: { encrypted: "true" } });
        attachment = { path, iv: media.iv, wrappedKeys: media.wrappedKeys, contentType: file.type, fileName: file.type.startsWith("audio/") ? "Voice message" : "Shared image", size: file.size, mediaKind: file.type.startsWith("audio/") ? "audio" : "image" };
      }
      const sentMessage = await addDoc(collection(db, "dm", routeId, "messages"), { uid: user.uid, participants, ...encrypted, ...(attachment ? { attachment } : {}), ...(replyTo && !editingId ? { replyToId: replyTo.id } : {}), reactions: {}, createdAt: serverTimestamp() });
      await setDoc(conversationRef, { updatedAt: serverTimestamp(), lastSenderUid: user.uid, lastMessagePreview: "🔒 Encrypted message" }, { merge: true });
      realtimeRef.current?.publishHint({ conversationId: routeId, messageId: sentMessage.id });
      setDraft(""); setReplyTo(null); setEditingId(null);
      await deleteDoc(doc(db, "dm", routeId, "typing", user.uid)).catch(() => {});
      setNotice(file ? "Encrypted attachment sent." : "Message sent securely.");
    } catch (e: any) { setError(e?.message || "Message could not be sent."); }
    finally { setBusy(false); }
  };
  const sendMessage = (event: FormEvent) => { event.preventDefault(); const text = draft.trim(); if (!text) return; if (text.length > 4000) { setError("Messages must be 4,000 characters or fewer."); return; } void sendPayload(text); };
  const reactToMessage = async (message: Message, emoji: string) => {
    if (!user || !routeId) return;
    try { await updateDoc(doc(db, "dm", routeId, "messages", message.id), { [`reactions.${user.uid}`]: message.reactions?.[user.uid] === emoji ? "" : emoji }); }
    catch (e: any) { setError(e?.message || "Reaction could not be saved."); }
  };
  const beginEdit = (message: Message) => { if (message.uid !== user?.uid || !decrypted[message.id]) return; setEditingId(message.id); setReplyTo(null); setDraft(decrypted[message.id]); };
  const saveEdit = async () => {
    if (!user || !routeId || !editingId || !draft.trim()) return;
    const message = messages.find(m => m.id === editingId); if (!message || message.uid !== user.uid) return;
    setBusy(true); try {
      const participants = (await getDoc(doc(db, "dm", routeId))).data()?.participants as string[];
      const recipient = participants.find(uid => uid !== user.uid)!;
      const encrypted = await encryptDirectMessage(user.uid, recipient, draft.trim());
      await updateDoc(doc(db, "dm", routeId, "messages", editingId), { ...encrypted, editedAt: serverTimestamp() });
      setDraft(""); setEditingId(null); setNotice("Message edited and re-encrypted on this device.");
    } catch (e: any) { setError(e?.message || "Message could not be edited."); } finally { setBusy(false); }
  };
  const removeMessage = async (message: Message) => {
    if (!user || !routeId || message.uid !== user.uid || !window.confirm("Delete this message for everyone in this conversation?")) return;
    try { await deleteDoc(doc(db, "dm", routeId, "messages", message.id)); }
    catch (e: any) { setError(e?.message || "Message could not be deleted."); }
  };
  const sendFile = async (file?: File) => { if (!file) return; if (!file.type.startsWith("image/")) { setError("Choose an image file."); return; } await sendPayload("", file); if (fileInput.current) fileInput.current.value = ""; };
  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { setError("Voice recording is not supported by this browser."); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true }); streamRef.current = stream; recordingChunks.current = [];
      const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
      const instance = new MediaRecorder(stream, { mimeType: mime }); recorder.current = instance;
      instance.ondataavailable = event => { if (event.data.size) recordingChunks.current.push(event.data); };
      instance.onstop = async () => { if (recordingTimer.current) clearInterval(recordingTimer.current); const blob = new Blob(recordingChunks.current, { type: instance.mimeType || "audio/webm" }); stream.getTracks().forEach(track => track.stop()); streamRef.current = null; setRecording(false); if (blob.size) await sendPayload("", blob); };
      instance.start(); setRecording(true); setRecordSeconds(0); const started = Date.now();
      recordingTimer.current = window.setInterval(() => { const seconds = Math.floor((Date.now() - started) / 1000); setRecordSeconds(seconds); if (seconds >= 60 && recorder.current?.state === "recording") recorder.current.stop(); }, 500);
    } catch (e: any) { setError(e?.message || "Microphone permission was not granted."); }
  };
  const stopRecording = () => { if (recordingTimer.current) clearInterval(recordingTimer.current); if (recorder.current?.state === "recording") recorder.current.stop(); };
  useEffect(() => () => { if (recordingTimer.current) clearInterval(recordingTimer.current); streamRef.current?.getTracks().forEach(t => t.stop()); }, []);

  const title = useMemo(() => activePerson?.displayName || (activePerson?.username ? `@${activePerson.username}` : "Conversation"), [activePerson]);
  const online = isOnline(presence[activePerson?.uid || ""]?.updatedAt) && presence[activePerson?.uid || ""]?.active !== false;
  if (!user) return <section className="page narrow"><div className="card">Please <Link to="/login">log in</Link> to use messages.</div></section>;

  return <section className="page messages-page">
    <div className="messages-heading"><div><p className="eyebrow">PRIVATE CONVERSATIONS</p><h1>Messages</h1><p className="muted">Message content and attachments are encrypted before upload.</p></div><span className="encryption-badge">🔒 End-to-end encryption</span></div>
    <div className="messages-layout">
      <aside className="conversation-panel card">
        <form className="dm-search" onSubmit={searchUsers}><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Find people by username" aria-label="Find people by username"/><button className="button" disabled={busy}>Find</button></form>
        {results.length > 0 && <div className="dm-results"><strong>People</strong>{results.map(person => <button key={person.uid} className="person-row" onClick={() => startConversation(person)} disabled={busy}><span className="avatar">{(person.displayName || person.username || "U").slice(0,1).toUpperCase()}</span><span><b>{person.displayName || "Happy Chat user"}</b><small>@{person.username || "user"}</small></span><span className="person-action">Message</span></button>)}</div>}
        <div className="conversation-list"><h2>Recent chats</h2>{conversations.length ? conversations.map(c => { const other = c.participants.find(uid => uid !== user.uid) || ""; const p = people[other]; return <Link key={c.id} to={`/messages/${c.id}`} className={`conversation-row ${routeId === c.id ? "selected" : ""}`}><span className="avatar">{(p?.displayName || p?.username || "U").slice(0,1).toUpperCase()}</span><span className="conversation-copy"><b>{p?.displayName || p?.username || "Conversation"}</b><small>{c.lastMessagePreview || "Start a conversation"}</small></span><small>{timeLabel(c.updatedAt)}</small></Link>; }) : <p className="muted small-note">No conversations yet. Find someone above to start chatting.</p>}</div>
      </aside>
      <section className="chat-panel card">
        {routeId ? <>
          <header className="chat-header"><div className="avatar">{(activePerson?.displayName || activePerson?.username || "U").slice(0,1).toUpperCase()}</div><div><b>{title}</b><small className={online ? "presence-online" : ""}>{online ? "● Online" : "○ Offline"}{activePerson?.username ? ` · @${activePerson.username}` : " · Private conversation"}</small></div><span className="secure-label">Encrypted</span></header>
          <div className="message-stream" aria-live="polite">{messages.length ? messages.map(message => <article key={message.id} className={`message-bubble ${message.uid === user.uid ? "mine" : "theirs"}`}>
            {message.attachment && mediaUrls[message.id] && (message.attachment.mediaKind === "image" ? <img className="dm-image" src={mediaUrls[message.id]} alt="Encrypted shared image"/> : <audio className="dm-audio" controls src={mediaUrls[message.id]}/>)}
            {message.attachment && !mediaUrls[message.id] && <p className="attachment-loading">🔒 Decrypting {message.attachment.mediaKind}…</p>}
            {message.replyToId && <div className="reply-context">↪ Reply to an earlier message</div>}
            {decrypted[message.id] && <p>{decrypted[message.id]}</p>}
            <small>{message.uid === user.uid ? "You" : activePerson?.displayName || "Them"} · {timeLabel(message.createdAt)}{message.editedAt ? " · Edited" : ""}{message.uid === user.uid ? (message.readAt ? " · Read" : " · Sent") : ""}</small>
            <div className="message-actions"><button type="button" onClick={() => { setReplyTo(message); setEditingId(null); }}>Reply</button><button type="button" onClick={() => void reactToMessage(message, "👍")}>👍 {message.reactions?.[user.uid] === "👍" ? "✓" : ""}</button><button type="button" onClick={() => void reactToMessage(message, "❤️")}>❤️</button>{message.uid === user.uid && <><button type="button" onClick={() => beginEdit(message)}>Edit</button><button type="button" onClick={() => void removeMessage(message)}>Delete</button></>}</div>
          </article>) : <div className="chat-empty"><div>🔒</div><h2>Start a private conversation</h2><p>Messages are encrypted on your device before being stored.</p></div>}</div>
          {typingUsers.length > 0 && <div className="typing-indicator">{activePerson?.displayName || "Someone"} is typing…</div>}
          <form className="message-composer" onSubmit={editingId ? e => { e.preventDefault(); void saveEdit(); } : sendMessage}>{(replyTo || editingId) && <div className="composer-context">{editingId ? "Editing your message" : `Replying to ${replyTo?.uid === user.uid ? "your message" : activePerson?.displayName || "this message"}`}<button type="button" onClick={() => { setReplyTo(null); setEditingId(null); setDraft(""); }}>Cancel</button></div>}<textarea value={draft} onChange={e => { setDraft(e.target.value); publishTyping(); }} maxLength={4000} rows={2} placeholder="Write an encrypted message…" aria-label="Write a message"/><div className="composer-tools"><input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden onChange={e => void sendFile(e.target.files?.[0])}/><button type="button" className="tool-button" onClick={() => fileInput.current?.click()} disabled={busy} aria-label="Attach image">＋ Image</button>{recording ? <button type="button" className="tool-button recording" onClick={stopRecording}>■ Stop voice ({recordSeconds}s / 60s)</button> : <button type="button" className="tool-button" onClick={() => void startRecording()} disabled={busy}>🎙 Voice</button>}<span className="composer-spacer"/><button className="button" disabled={busy || !draft.trim()}>{busy ? "Saving…" : editingId ? "Save edit" : "Send"}</button></div><div className="composer-footer"><small>{draft.length}/4000 · {notice}</small></div></form>
        </> : <div className="chat-empty choose-chat"><div>💬</div><h2>Your conversations</h2><p>Choose a chat or find someone to send your first encrypted message.</p></div>}
      </section>
    </div>
    {error && <div className="error messages-error" role="alert">{error}</div>}
    <p className="messages-footnote">Voice notes and images are encrypted on this device before upload. Read receipts are visible to conversation participants. Online status uses a short heartbeat and may briefly show offline when a device loses connectivity. This is an initial E2EE implementation and has not received an independent security audit.</p>
  </section>;
}
