import { FormEvent, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { addDoc, collection, doc, getDoc, limit, onSnapshot, orderBy, query, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../firebase";

type RoomMessage = { id: string; uid: string; handle?: string; displayName?: string; text: string; createdAt?: any };
function clock(value: any) { const date = value?.toDate?.(); return date ? date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""; }

export default function ChatRoom() {
  const user = auth.currentUser;
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [profile, setProfile] = useState<{ username?: string; displayName?: string }>({});
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!user) return;
    let active = true;
    getDoc(doc(db, "profiles", user.uid)).then(s => {
      if (active && s.exists()) setProfile({ username: s.data().username, displayName: s.data().displayName });
    }).catch(() => undefined);
    const stop = onSnapshot(query(collection(db, "chat"), orderBy("createdAt", "desc"), limit(100)), snap => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as RoomMessage)).reverse());
    }, e => setError(e.message || "Could not load the live chat."));
    return () => { active = false; stop(); };
  }, [user?.uid]);

  const send = async (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!user || !text || sending) return;
    if (text.length > 500) { setError("Messages must be 500 characters or fewer."); return; }
    setSending(true); setError("");
    try {
      await addDoc(collection(db, "chat"), {
        uid: user.uid,
        handle: (profile.username || user.displayName || "user").slice(0, 30),
        displayName: (profile.displayName || user.displayName || "Happy Chat user").slice(0, 80),
        text,
        createdAt: serverTimestamp()
      });
      setDraft("");
    } catch (e: any) { setError(e?.message || "Your message could not be sent."); }
    finally { setSending(false); }
  };

  if (!user) return <section className="page narrow"><div className="card">Please <Link to="/login">log in</Link> to join the live chat.</div></section>;
  return <section className="page narrow live-chat-page">
    <div className="section-heading"><div><p className="eyebrow">HAPPY CHAT COMMUNITY</p><h1>Live Chat</h1><p className="muted">A shared public room. Do not post private information.</p></div><span className="live-pill">● Live</span></div>
    <div className="live-chat-card card">
      <div className="live-chat-stream" aria-live="polite">{messages.length ? messages.map(message => <article key={message.id} className={`room-message ${message.uid === user.uid ? "own" : ""}`}><div className="room-message-head"><b>{message.displayName || "Happy Chat user"}</b><span>@{message.handle || "user"} · {clock(message.createdAt)}</span></div><p>{message.text}</p></article>) : <div className="chat-empty"><div>🌐</div><h2>Say hello to the community</h2><p>Messages from the room will appear here in real time.</p></div>}</div>
      <form className="live-chat-composer" onSubmit={send}><textarea value={draft} onChange={e => setDraft(e.target.value)} rows={2} maxLength={500} placeholder="Write a public message…" aria-label="Write a public message"/><div><small>{draft.length}/500</small><button className="button" disabled={sending || !draft.trim()}>{sending ? "Sending…" : "Send message"}</button></div></form>
    </div>
    {error && <div className="error messages-error" role="alert">{error}</div>}
  </section>;
}
