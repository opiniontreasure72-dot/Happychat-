import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyARmDmmyERokHL2DbBti95Tl0F8crimuHo",
  authDomain: "opinion-df052.firebaseapp.com",
  projectId: "opinion-df052",
  storageBucket: "opinion-df052.firebasestorage.app",
  messagingSenderId: "469030416455",
  appId: "1:469030416455:web:8524b3eb357c6db936c162",
  measurementId: "G-RKM724788Q"
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const db = getFirestore(firebaseApp);
export const storage = getStorage(firebaseApp);
