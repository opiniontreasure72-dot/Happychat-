import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";

const DB_NAME = "happychat-dm-keys-v1";
const STORE = "identities";
type LocalIdentity = { publicJwk: JsonWebKey; privateJwk: JsonWebKey };

function openKeyDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function readIdentity(uid: string): Promise<LocalIdentity | null> {
  const database = await openKeyDb();
  return new Promise((resolve, reject) => {
    const request = database.transaction(STORE, "readonly").objectStore(STORE).get(uid);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}
async function saveIdentity(uid: string, identity: LocalIdentity): Promise<void> {
  const database = await openKeyDb();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE, "readwrite");
    transaction.objectStore(STORE).put(identity, uid);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}
const toBase64 = (buffer: ArrayBuffer) => {
  const bytes = new Uint8Array(buffer); let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
};
const fromBase64 = (value: string) => Uint8Array.from(atob(value), c => c.charCodeAt(0));

export async function ensureDmIdentity(uid: string): Promise<void> {
  if (!window.isSecureContext || !crypto.subtle) throw new Error("Secure messaging requires HTTPS and a supported browser.");
  let identity = await readIdentity(uid);
  const keyRef = doc(db, "userKeys", uid);
  const published = await getDoc(keyRef);
  if (!identity) {
    const pair = await crypto.subtle.generateKey({ name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["encrypt", "decrypt"]);
    identity = { publicJwk: await crypto.subtle.exportKey("jwk", pair.publicKey), privateJwk: await crypto.subtle.exportKey("jwk", pair.privateKey) };
    await saveIdentity(uid, identity);
  }
  if (!published.exists() || published.data().publicKey?.n !== identity.publicJwk.n || published.data().publicKey?.e !== identity.publicJwk.e) {
    await setDoc(keyRef, { publicKey: identity.publicJwk, version: 1, updatedAt: serverTimestamp() });
  }
}

export async function encryptDirectMessage(senderUid: string, recipientUid: string, text: string) {
  await ensureDmIdentity(senderUid);
  const senderIdentity = await readIdentity(senderUid);
  if (!senderIdentity) throw new Error("Your encryption key is unavailable on this device.");
  const recipientDoc = await getDoc(doc(db, "userKeys", recipientUid));
  const senderDoc = await getDoc(doc(db, "userKeys", senderUid));
  if (!recipientDoc.exists() || !senderDoc.exists()) throw new Error("Both people must open Messages once to enable encrypted messaging.");
  const rawRecipient = recipientDoc.data().publicKey as JsonWebKey;
  const rawSender = senderDoc.data().publicKey as JsonWebKey;
  const aes = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aes, new TextEncoder().encode(text));
  const rawAes = await crypto.subtle.exportKey("raw", aes);
  const wrap = async (jwk: JsonWebKey) => {
    const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
    return toBase64(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, key, rawAes));
  };
  return { ciphertext: toBase64(ciphertext), iv: toBase64(iv.buffer as ArrayBuffer), wrappedKeys: { [senderUid]: await wrap(rawSender), [recipientUid]: await wrap(rawRecipient) }, e2eeVersion: 1 };
}

export async function decryptDirectMessage(uid: string, message: { ciphertext: string; iv: string; wrappedKeys: Record<string, string> }): Promise<string> {
  const identity = await readIdentity(uid);
  const wrapped = message.wrappedKeys?.[uid];
  if (!identity || !wrapped) throw new Error("This device does not have the key needed to decrypt this message.");
  const privateKey = await crypto.subtle.importKey("jwk", identity.privateJwk, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
  const rawAes = await crypto.subtle.decrypt({ name: "RSA-OAEP" }, privateKey, fromBase64(wrapped));
  const aes = await crypto.subtle.importKey("raw", rawAes, { name: "AES-GCM" }, false, ["decrypt"]);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(message.iv) }, aes, fromBase64(message.ciphertext));
  return new TextDecoder().decode(plain);
}

/** Encrypt an attachment in the browser before it is uploaded. Only the two
 * conversation participants receive a wrapped copy of its AES key. */
export async function encryptDmAttachment(senderUid: string, recipientUid: string, file: Blob) {
  await ensureDmIdentity(senderUid);
  const recipientDoc = await getDoc(doc(db, "userKeys", recipientUid));
  const senderDoc = await getDoc(doc(db, "userKeys", senderUid));
  if (!recipientDoc.exists() || !senderDoc.exists()) throw new Error("Both people must open Messages once before sharing encrypted media.");
  const aes = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, aes, await file.arrayBuffer());
  const rawAes = await crypto.subtle.exportKey("raw", aes);
  const wrap = async (jwk: JsonWebKey) => {
    const publicKey = await crypto.subtle.importKey("jwk", jwk, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
    return toBase64(await crypto.subtle.encrypt({ name: "RSA-OAEP" }, publicKey, rawAes));
  };
  return {
    encrypted: new Blob([encrypted], { type: "application/octet-stream" }),
    iv: toBase64(iv.buffer as ArrayBuffer),
    wrappedKeys: {
      [senderUid]: await wrap(senderDoc.data().publicKey as JsonWebKey),
      [recipientUid]: await wrap(recipientDoc.data().publicKey as JsonWebKey)
    }
  };
}

export async function decryptDmAttachment(uid: string, iv: string, wrappedKeys: Record<string, string>, encrypted: ArrayBuffer): Promise<Blob> {
  const identity = await readIdentity(uid);
  const wrapped = wrappedKeys?.[uid];
  if (!identity || !wrapped) throw new Error("This device does not have the key needed to decrypt this attachment.");
  const privateKey = await crypto.subtle.importKey("jwk", identity.privateJwk, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["decrypt"]);
  const rawAes = await crypto.subtle.decrypt({ name: "RSA-OAEP" }, privateKey, fromBase64(wrapped));
  const aes = await crypto.subtle.importKey("raw", rawAes, { name: "AES-GCM" }, false, ["decrypt"]);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(iv) }, aes, encrypted);
  return new Blob([plain]);
}
