/** Optional realtime hint transport. Firestore remains the durable source of truth. */
export type RealtimeHint = { conversationId: string; messageId: string };
type Listener = (hint: RealtimeHint) => void;

export class RealtimeTransport {
  private socket: WebSocket | null = null;
  private listeners = new Set<Listener>();
  private retryTimer: number | undefined;
  private closed = false;
  private token = "";
  private subscriptions = new Set<string>();
  private reconnectDelay = 1000;
  private forceRefresh = false;

  constructor(private readonly url: string, private readonly getToken: (forceRefresh?: boolean) => Promise<string>) {}
  connect() {
    if (this.closed || !this.url || this.socket?.readyState === WebSocket.OPEN || this.socket?.readyState === WebSocket.CONNECTING) return;
    void this.open();
  }
  private async open() {
    try {
      this.token = await this.getToken(this.forceRefresh);
      this.forceRefresh = false;
      if (this.closed) return;
      const ws = new WebSocket(this.url);
      this.socket = ws;
      ws.onopen = () => {
        this.reconnectDelay = 1000;
        ws.send(JSON.stringify({ type: "authenticate", token: this.token }));
      };
      ws.onmessage = event => {
        try {
          const data = JSON.parse(String(event.data));
          if (data.type === "authenticated") {
            for (const conversationId of this.subscriptions) ws.send(JSON.stringify({ type: "subscribe", conversationId }));
          } else if (data.type === "sync_hint" && typeof data.conversationId === "string" && typeof data.messageId === "string") {
            this.listeners.forEach(listener => listener({ conversationId: data.conversationId, messageId: data.messageId }));
          }
        } catch { /* Ignore malformed frames. */ }
      };
      ws.onclose = event => { if (this.socket === ws) this.socket = null; if (event.code === 4401) this.forceRefresh = true; this.scheduleReconnect(); };
      ws.onerror = () => ws.close();
    } catch { this.scheduleReconnect(); }
  }
  private scheduleReconnect() {
    if (this.closed || this.retryTimer !== undefined) return;
    this.retryTimer = window.setTimeout(() => { this.retryTimer = undefined; this.connect(); }, this.reconnectDelay);
    this.reconnectDelay = Math.min(this.reconnectDelay * 2, 30_000);
  }
  subscribe(conversationId: string) {
    this.subscriptions.add(conversationId);
    if (this.socket?.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify({ type: "subscribe", conversationId }));
    return () => {
      this.subscriptions.delete(conversationId);
      if (this.socket?.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify({ type: "unsubscribe", conversationId }));
    };
  }
  publishHint(hint: RealtimeHint) {
    if (this.socket?.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify({ type: "message_hint", ...hint }));
  }
  onHint(listener: Listener) { this.listeners.add(listener); return () => this.listeners.delete(listener); }
  close() {
    this.closed = true;
    if (this.retryTimer !== undefined) window.clearTimeout(this.retryTimer);
    this.socket?.close(1000, "client shutdown"); this.socket = null; this.listeners.clear(); this.subscriptions.clear();
  }
}
