/**
 * Happy Chat End-to-End Encryption service.
 * Uses Web Crypto API: RSA-OAEP-2048 for key wrapping and AES-256-GCM
 * for direct-message content. Private keys remain on the user's device.
 */
(function(){
  "use strict";
  const DB_NAME = "happyChatE2EE";
  const STORE = "keys";
  const VERSION = 1;

  function supported(){
    return !!(window.crypto && window.crypto.subtle && window.isSecureContext);
  }
  function ab64(buf){
    const bytes = new Uint8Array(buf);
    let s = "";
    const chunk = 0x8000;
    for(let i=0;i<bytes.length;i+=chunk){
      s += String.fromCharCode(...bytes.subarray(i, Math.min(i+chunk, bytes.length)));
    }
    return btoa(s);
  }
  function b64ab(s){
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
    return out.buffer;
  }
  function openDb(){
    return new Promise((resolve,reject)=>{
      const req=indexedDB.open(DB_NAME,VERSION);
      req.onupgradeneeded=()=>{ if(!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error);
    });
  }
  async function getLocal(uid){
    const db=await openDb();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readonly"), req=tx.objectStore(STORE).get(uid);
      req.onsuccess=()=>resolve(req.result||null); req.onerror=()=>reject(req.error);
    });
  }
  async function putLocal(uid,value){
    const db=await openDb();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readwrite");
      tx.objectStore(STORE).put(value,uid);
      tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error);
    });
  }
  async function importPublic(jwk){
    return crypto.subtle.importKey("jwk",jwk,{name:"RSA-OAEP",hash:"SHA-256"},false,["encrypt"]);
  }
  async function importPrivate(jwk){
    return crypto.subtle.importKey("jwk",jwk,{name:"RSA-OAEP",hash:"SHA-256"},false,["decrypt"]);
  }
  async function ensureIdentity(uid, profileRef){
    if(!supported()) throw new Error("End-to-end encryption requires a secure browser (HTTPS).");
    let local=await getLocal(uid);
    let profile=(await profileRef.get()).data()||{};
    if(!local || !local.privateJwk || !local.publicJwk){
      const pair=await crypto.subtle.generateKey(
        {name:"RSA-OAEP",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-256"},
        true,["encrypt","decrypt"]
      );
      const publicJwk=await crypto.subtle.exportKey("jwk",pair.publicKey);
      const privateJwk=await crypto.subtle.exportKey("jwk",pair.privateKey);
      local={publicJwk,privateJwk,createdAt:Date.now()};
      await putLocal(uid,local);
      await profileRef.set({e2eePublicKey:publicJwk,e2eeVersion:1,e2eeUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
    } else if(!profile.e2eePublicKey){
      await profileRef.set({e2eePublicKey:local.publicJwk,e2eeVersion:1,e2eeUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
    }
    return local.publicJwk;
  }
  async function wrapKey(aesKey, publicJwk){
    const publicKey=await importPublic(publicJwk);
    const raw=await crypto.subtle.exportKey("raw",aesKey);
    return ab64(await crypto.subtle.encrypt({name:"RSA-OAEP"},publicKey,raw));
  }
  async function unwrapKey(uid,wrapped){
    if(!wrapped || !wrapped[uid]) throw new Error("This device does not have the key for this message.");
    const local=await getLocal(uid);
    if(!local) throw new Error("This device's encryption key is unavailable.");
    const privateKey=await importPrivate(local.privateJwk);
    const raw=await crypto.subtle.decrypt({name:"RSA-OAEP"},privateKey,b64ab(wrapped[uid]));
    return crypto.subtle.importKey("raw",raw,{name:"AES-GCM"},false,["encrypt","decrypt"]);
  }
  async function encryptBytes(aesKey,bytes){
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const out=await crypto.subtle.encrypt({name:"AES-GCM",iv},aesKey,bytes);
    return {iv:ab64(iv),data:ab64(out),buffer:out};
  }
  async function decryptBytes(aesKey,iv,data){
    return crypto.subtle.decrypt({name:"AES-GCM",iv:new Uint8Array(b64ab(iv))},aesKey,b64ab(data));
  }
  async function createEnvelope(uid, participants, text, file){
    if(!supported()) throw new Error("End-to-end encryption is not supported in this browser.");
    const pubs=participants.filter(p=>p && p.uid && p.e2eePublicKey);
    if(pubs.length!==participants.length) throw new Error("The other participant has not enabled end-to-end encryption yet. Ask them to open Happy Chat once and try again.");
    const aesKey=await crypto.subtle.generateKey({name:"AES-GCM",length:256},true,["encrypt","decrypt"]);
    const wrappedKeys={};
    for(const p of pubs) wrappedKeys[p.uid]=await wrapKey(aesKey,p.e2eePublicKey);
    const result={e2ee:true,e2eeVersion:1,wrappedKeys};
    if(text){
      const enc=await encryptBytes(aesKey,new TextEncoder().encode(text));
      result.textCipher=enc.data; result.textIv=enc.iv;
    }
    if(file){
      const raw=await file.arrayBuffer();
      const enc=await encryptBytes(aesKey,raw);
      result.videoCipher=enc.data; result.videoIv=enc.iv; result.videoMime=file.type||"video/mp4";
      result.videoBlob=new Blob([enc.buffer],{type:"application/octet-stream"});
    }
    return result;
  }
  async function decryptMessage(uid,msg){
    if(!msg.e2ee) return {text:msg.text||"", videoUrl:msg.videoUrl||""};
    const aesKey=await unwrapKey(uid,msg.wrappedKeys);
    let text="";
    if(msg.textCipher) text=new TextDecoder().decode(await decryptBytes(aesKey,msg.textIv,msg.textCipher));
    return {text, videoUrl:msg.videoUrl||"", aesKey};
  }
  async function decryptMedia(uid,msg){
    const aesKey=await unwrapKey(uid,msg.wrappedKeys);
    const response=await fetch(msg.videoUrl,{cache:"no-store"});
    if(!response.ok) throw new Error("Encrypted media could not be downloaded.");
    const buf=await response.arrayBuffer();
    const plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:new Uint8Array(b64ab(msg.videoIv))},aesKey,buf);
    return URL.createObjectURL(new Blob([plain],{type:msg.videoMime||"video/mp4"}));
  }

  window.HappyChatE2EE={
    supported,
    ensureIdentity,
    createEnvelope,
    decryptMessage,
    decryptMedia
  };
})();