# Happy Chat direct messaging

## Included
- Authenticated public live-chat room using Firestore real-time listeners.
- Authenticated 1-to-1 conversations using Firestore real-time listeners.
- Username search restricted to profiles with `isPrivate: false`.
- Deterministic conversation IDs to avoid duplicate threads between the same two accounts.
- Text messages encrypted in the browser with a fresh AES-256-GCM key per message. That key is wrapped for both participants using RSA-OAEP-2048.
- Private key material is kept in browser IndexedDB; only public keys are published to `userKeys/{uid}`.
- Message previews never contain message text.

## Live room

The `/chat` route uses the existing append-only `chat` collection rules. Room messages are public to signed-in users and are not end-to-end encrypted; users should not share private information there.

## Required profile data
New signups now request a unique lowercase username and create both a `/usernames/{username}` reservation and `/profiles/{uid}` document in one Firestore transaction. Existing accounts must have a matching public profile document with a lowercase `username` and `isPrivate: false` added before they appear in search. Users must open the Messages page once on each device/browser to create and publish their public encryption key before another user can send them an encrypted message.

## Firebase deployment
1. Back up the Firebase project and export current Firestore data before changing rules.
2. Confirm existing profile documents use the fields permitted by `firestore.rules`.
3. Deploy Firestore rules and indexes from the project root:
   - `firebase deploy --only firestore:rules,firestore:indexes`
4. Run two test accounts in separate browsers. Open Messages on both accounts, search the other by username, start a conversation, and exchange messages in both directions.
5. Verify in Firestore that `/dm/{conversationId}/messages/{messageId}` contains only ciphertext, IV, wrapped keys, participant UIDs, sender UID, version and timestamp—never plaintext message text.
6. Verify an unrelated signed-in account cannot read the conversation or its messages.

## Security limitations
This is an initial E2EE implementation, not a security-audited messaging protocol. It does not yet provide forward secrecy, verified identity fingerprints, multi-device key recovery, attachments, voice/video calls, group chats, message deletion, read receipts, or blocking/reporting controls. Losing browser IndexedDB data can make old messages unreadable. Do not describe this as Signal-grade or independently audited. A production release should migrate to a vetted protocol/library and undergo an external security review.

## Build verification
Run `npm ci`, `npm run typecheck`, `npm run build`, then Firebase Emulator tests before deployment. Dependency installation could not be completed in the current build environment, so the production build remains unverified.
