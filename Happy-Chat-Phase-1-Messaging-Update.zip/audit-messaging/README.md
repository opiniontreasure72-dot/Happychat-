# Happy Chat 4.1 — SPA foundation

Happy Chat is the social platform and Opinion is its integrated AI assistant.

## Current architecture
- Vite + React + TypeScript
- React Router browser routing
- Firebase Auth / Firestore / Storage client SDK
- Vercel deployment with SPA fallback
- No service worker or offline content cache
- Public routes can be viewed without signing in; interaction remains account-gated
- Existing legacy implementation is retained temporarily as `legacy.html` during incremental migration

## Routes
`/`, `/post/:id`, `/u/:handle`, `/messages`, `/messages/:conversationId`, `/reels`, `/stories/:uid`, `/search`, `/notifications`, `/settings`, `/opinion`, `/login`, `/signup`, `/reset-password`, `/legal/terms`, `/legal/privacy`, and a 404 route.

## Development
```bash
npm install
npm run dev
npm run typecheck
npm run build
```

## Migration note
This release establishes the SPA shell and routing without claiming that every legacy feature has already been migrated. E2EE, moderation, server-authoritative counters, video processing, and security hardening remain separate work items.


## Unified Social Engine foundation
A separate, sandbox-only USE scaffold is available in `USE/`. It is not wired into production routes and contains no real-money or custom cryptographic implementation. Read `USE/README.md` and `USE/SECURITY-DECISIONS.md` before integration.

## Phase 1 Foundations
See [PHASE_1_FOUNDATIONS.md](./PHASE_1_FOUNDATIONS.md) for the cost-minimised implementation notes, emulator test commands, migration steps, and known risks. No production deployment or database migration is performed by this package.

### Messaging update
The current direct-message implementation now includes typing indicators, replies, emoji reactions, encrypted message editing, and author-only deletion. It remains one-to-one only. Group chat is intentionally not enabled until multi-recipient E2EE key distribution and group membership controls are implemented and tested. Deploy the updated `firestore.rules` alongside the frontend.
