# Messaging media, receipts and presence update

This update adds browser-side encrypted image and voice-note attachments, read receipts, and short-lived online presence to the existing direct-message page.

## Features
- Images: JPEG, PNG, WebP and GIF; maximum 8 MB before encryption.
- Voice notes: microphone capture with a 60-second limit; maximum 8 MB before encryption.
- Attachments are encrypted in the browser with AES-GCM. The attachment key is wrapped separately for the two conversation participants. Only ciphertext is uploaded to `dmMedia/{conversationId}/{senderUid}/{file}.bin`.
- The recipient downloads ciphertext through authenticated Firebase Storage access and decrypts locally.
- Read receipts are a one-time `readAt` timestamp set by the recipient. The sender sees `Read` after it is written.
- Presence heartbeats are written every 30 seconds. A participant is displayed as online only when the last heartbeat is less than 75 seconds old.

## Firebase deployment
1. Back up the Firestore and Storage rules currently deployed.
2. Deploy the updated `firestore.rules` and `storage.rules` from this project.
3. Ensure Firebase Storage is enabled for the configured project and that the app is served over HTTPS (required for microphone access and Web Crypto).
4. Test using two separate accounts and two separate browsers/devices: text, image, voice note, read receipt, online/offline, and access denial for a third account.

Example Firebase CLI commands from the project root:

```sh
firebase deploy --only firestore:rules,storage
```

## Important limitations
- Online status is heartbeat-based, not a guaranteed instant offline signal. Mobile operating systems can suspend background tabs.
- Read receipts show that a message was opened by the recipient's client; they do not prove that a person read or understood it.
- The existing RSA-OAEP/AES-GCM DM design is an initial implementation, not an independently audited messaging protocol. It does not provide forward secrecy, robust key-change verification, or protection against a compromised device. Do not advertise it as independently verified or equivalent to Signal's protocol.
- Firebase download permissions protect the object through authenticated Storage rules. The uploaded object is ciphertext; its encryption key is only wrapped for the two participants.
