import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('realtime gateway is optional and Firestore remains durable fallback', () => {
  const page = readFileSync(new URL('../src/pages/Messages.tsx', import.meta.url), 'utf8');
  assert.match(page, /VITE_REALTIME_WS_URL/);
  assert.match(page, /onSnapshot\(query\(collection\(db, "dm", routeId, "messages"\)/);
  assert.match(page, /publishHint\(\{ conversationId: routeId, messageId: sentMessage.id \}\)/);
});

test('gateway verifies Firebase identity and checks conversation membership', () => {
  const gateway = readFileSync(new URL('../realtime-gateway/src/server.js', import.meta.url), 'utf8');
  assert.match(gateway, /verifyIdToken\(msg\.token, true\)/);
  assert.match(gateway, /snap\.data\(\)\.participants\.includes\(ws\.uid\)/);
  assert.match(gateway, /message\.data\(\)\.uid !== ws\.uid/);
  assert.match(gateway, /sync_hint/);
});

test('gateway rate-limits frames, expires auth sessions, and cancels pending subscriptions', () => {
  const gateway = readFileSync(new URL('../realtime-gateway/src/server.js', import.meta.url), 'utf8');
  assert.match(gateway, /ws\.rate\.tokens/);
  assert.match(gateway, /decoded\.exp \* 1000/);
  assert.match(gateway, /ws\.pendingRooms\.delete/);
});

test('realtime hints trigger a durable Firestore refresh', () => {
  const page = readFileSync(new URL('../src/pages/Messages.tsx', import.meta.url), 'utf8');
  assert.match(page, /transport\.onHint/);
  assert.match(page, /getDocs\(query\(collection\(db, "dm", routeId, "messages"\)/);
});
