import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = path => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('messaging page includes image and voice note controls with size and duration limits', () => {
  const source = read('src/pages/Messages.tsx');
  assert.match(source, /accept="image\/jpeg,image\/png,image\/webp,image\/gif"/);
  assert.match(source, /file\.size > 8 \* 1024 \* 1024/);
  assert.match(source, /seconds >= 60/);
  assert.match(source, /getUserMedia\(\{ audio: true \}\)/);
});

test('DM attachment encryption happens before Storage upload', () => {
  const source = read('src/pages/Messages.tsx');
  assert.ok(source.indexOf('encryptDmAttachment(user.uid, recipient, file)') < source.indexOf('uploadBytes(ref(storage, path)'));
  assert.match(read('src/services/dm-crypto.ts'), /AES-GCM/);
  assert.match(read('src/services/dm-crypto.ts'), /RSA-OAEP/);
});

test('Firestore rules limit receipts and presence to conversation participants', () => {
  const rules = read('firestore.rules');
  assert.match(rules, /affectedKeys\(\)\.hasOnly\(\['readAt'\]\)/);
  assert.match(rules, /function sharesConversation\(\)/);
  assert.match(rules, /request\.resource\.data\.updatedAt == request\.time/);
});

test('Storage rules protect encrypted DM media to conversation participants', () => {
  const rules = read('storage.rules');
  assert.match(rules, /match \/dmMedia\/{conversationId}\/{uid}\/{fileName}/);
  assert.match(rules, /firestore\.get\(\/databases\/\(default\)\/documents\/dm\/\$\(conversationId\)\)/);
  assert.match(rules, /request\.resource\.contentType == 'application\/octet-stream'/);
});
