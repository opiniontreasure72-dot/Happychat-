import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { initializeTestEnvironment, RulesTestEnvironment, assertFails, assertSucceeds } from "@firebase/rules-unit-testing";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { ref, getBytes, uploadBytes } from "firebase/storage";
import { readFileSync } from "node:fs";

let env: RulesTestEnvironment;
const projectId = "happy-chat-phase1-test";
beforeAll(async () => {
  env = await initializeTestEnvironment({ projectId, firestore: { rules: readFileSync("firestore.rules", "utf8") }, storage: { rules: readFileSync("storage.rules", "utf8") } });
});
afterAll(async () => { await env.cleanup(); });
beforeEach(async () => {
  await env.clearFirestore(); await env.clearStorage();
  await env.withSecurityRulesDisabled(async context => {
    await setDoc(doc(context.firestore(), "profiles/alice"), { uid:"alice", username:"alice", displayName:"Alice", photoURL:"", bio:"", isPrivate:false });
    await setDoc(doc(context.firestore(), "profiles/private"), { uid:"private", username:"privateuser", displayName:"Private", photoURL:"", bio:"", isPrivate:true });
    await setDoc(doc(context.firestore(), "posts/public1"), { uid:"alice", handle:"alice", displayName:"Alice", text:"Hello", visibility:"public", createdAt:new Date() });
    await setDoc(doc(context.firestore(), "posts/private1"), { uid:"private", handle:"privateuser", displayName:"Private", text:"Secret", visibility:"private", createdAt:new Date() });
    await setDoc(doc(context.firestore(), "dm/alice__bob"), { participants:["alice","bob"], createdBy:"alice", lastMessagePreview:"" });
    await setDoc(doc(context.firestore(), "dm/alice__bob/messages/m1"), { uid:"alice", participants:["alice","bob"], ciphertext:"cipher", iv:"iv", wrappedKeys:{alice:"a",bob:"b"}, e2eeVersion:1 });
  });
});
describe("Phase 1 security rules", () => {
  it("allows anonymous reads of public profiles and public posts only", async () => {
    const db = env.unauthenticatedContext().firestore();
    await assertSucceeds(getDoc(doc(db,"profiles/alice")));
    await assertFails(getDoc(doc(db,"profiles/private")));
    await assertSucceeds(getDoc(doc(db,"posts/public1")));
    await assertFails(getDoc(doc(db,"posts/private1")));
  });
  it("denies cross-user profile writes", async () => {
    const db = env.authenticatedContext("bob").firestore();
    await assertFails(updateDoc(doc(db,"profiles/alice"), { displayName:"Hijacked" }));
  });
  it("denies DM sender spoofing", async () => {
    const db = env.authenticatedContext("bob").firestore();
    await assertFails(setDoc(doc(db,"dm/alice__bob/messages/spoof"), { uid:"alice", participants:["alice","bob"], ciphertext:"cipher", iv:"iv", wrappedKeys:{alice:"a",bob:"b"}, e2eeVersion:1 }));
  });
  it("denies anonymous reads of encrypted DM Storage objects", async () => {
    await env.withSecurityRulesDisabled(async context => { await uploadBytes(ref(context.storage(),"dmMedia/alice__bob/alice/test.bin"), new Uint8Array([1,2,3]), { contentType:"application/octet-stream", customMetadata:{encrypted:"true"} }); });
    await assertFails(getBytes(ref(env.unauthenticatedContext().storage(),"dmMedia/alice__bob/alice/test.bin")));
    await assertSucceeds(getBytes(ref(env.authenticatedContext("bob").storage(),"dmMedia/alice__bob/alice/test.bin")));
  });
});
