import { describe, expect, it, vi } from "vitest";
import { RealtimeTransport } from "../src/services/realtime-transport";

describe("RealtimeTransport", () => {
  it("registers and removes sync-hint listeners", () => {
    const transport = new RealtimeTransport("", async () => "unused");
    const listener = vi.fn();
    const unsubscribe = transport.onHint(listener);
    expect(typeof unsubscribe).toBe("function");
    unsubscribe();
    transport.close();
    expect(listener).not.toHaveBeenCalled();
  });
  it("keeps Firestore fallback when no gateway URL is configured", () => {
    const transport = new RealtimeTransport("", async () => "unused");
    expect(() => transport.connect()).not.toThrow();
    expect(() => transport.publishHint({ conversationId: "alice__bob", messageId: "m1" })).not.toThrow();
    transport.close();
  });
});
