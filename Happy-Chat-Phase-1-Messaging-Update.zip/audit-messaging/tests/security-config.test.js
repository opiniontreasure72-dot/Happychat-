import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = path => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('AI endpoints share the security gate before provider access', () => {
  for (const endpoint of ['api/chat.js', 'api/image.js', 'api/speak.js']) {
    const source = read(endpoint);
    assert.match(source, /await protect\(req, res,/);
    assert.ok(source.indexOf('await protect(req, res,') < source.indexOf('https://api.openai.com/'));
  }
});

test('security middleware requires an explicit origin and Firebase Admin token verification', () => {
  const source = read('api/_security.js');
  assert.match(source, /if \(!configured \|\| configured\.includes\('\*'\)\) return \[\]/);
  assert.match(source, /verifyIdToken\(token, true\)/);
  assert.doesNotMatch(source, /ALLOW_UNVERIFIED_FIREBASE/);
  assert.match(source, /MAX_JSON_BYTES = 1 \* 1024 \* 1024/);
  assert.match(source, /runTransaction/);
});

test('usage collection is denied to client SDKs', () => {
  assert.match(read('firestore.rules'), /match \/_apiUsage\/{usageId} \{ allow read, write: if false; \}/);
});

test('deployment headers include baseline browser protections', () => {
  const config = JSON.parse(read('vercel.json'));
  const headers = JSON.stringify(config.headers);
  for (const header of ['Strict-Transport-Security', 'X-Content-Type-Options', 'Referrer-Policy', 'X-Frame-Options', 'Content-Security-Policy-Report-Only']) assert.ok(headers.includes(header), `Missing ${header}`);
});
