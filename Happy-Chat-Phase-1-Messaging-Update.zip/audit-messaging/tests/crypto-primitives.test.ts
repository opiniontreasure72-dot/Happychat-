import { describe, expect, it } from "vitest";

describe("E2EE cryptographic primitives", () => {
  it("round-trips AES-256-GCM ciphertext and rejects a modified ciphertext", async () => {
    const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plain = new TextEncoder().encode("Happy Chat encrypted message");
    const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plain);
    const opened = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipher);
    expect(new TextDecoder().decode(opened)).toBe("Happy Chat encrypted message");
    const altered = new Uint8Array(cipher); altered[0] ^= 1;
    await expect(crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, altered)).rejects.toThrow();
  });
  it("wraps and unwraps a message key with RSA-OAEP-2048", async () => {
    const pair = await crypto.subtle.generateKey({ name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([1,0,1]), hash: "SHA-256" }, true, ["encrypt", "decrypt"]);
    const raw = crypto.getRandomValues(new Uint8Array(32));
    const wrapped = await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pair.publicKey, raw);
    const unwrapped = await crypto.subtle.decrypt({ name: "RSA-OAEP" }, pair.privateKey, wrapped);
    expect(Array.from(new Uint8Array(unwrapped))).toEqual(Array.from(raw));
  });
});
